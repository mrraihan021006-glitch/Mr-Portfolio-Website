"use client";

import React, { useState, useEffect, useRef, Component, ErrorInfo, ReactNode } from 'react';
import { supabase } from './supabase'; 

const CLOUD_NAME = "dbkmg0oia";
const UPLOAD_PRESET = "raihan_metadata";

// ==========================================
// 🛡️ ERROR BOUNDARY (PREVENTS WHITE SCREEN)
// ==========================================
class ErrorBoundary extends Component<{children: ReactNode}, {hasError: boolean, error: Error | null}> {
  constructor(props: {children: ReactNode}) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("React Error Caught By Boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#020617', color: 'white', padding: '20px', fontFamily: 'sans-serif' }}>
          <div style={{ backgroundColor: 'rgba(225, 29, 72, 0.1)', border: '1px solid rgba(225, 29, 72, 0.3)', padding: '30px', borderRadius: '15px', maxWidth: '600px' }}>
            <h2 style={{ color: '#fb7185', fontSize: '24px', marginBottom: '15px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span>⚠️</span> Application Error
            </h2>
            <p style={{ color: '#e2e8f0', marginBottom: '10px' }}>Something went wrong, but the Error Boundary prevented a white screen. (Likely a missing import or undefined variable)</p>
            <div style={{ backgroundColor: '#0f172a', padding: '15px', borderRadius: '8px', color: '#fb7185', fontFamily: 'monospace', fontSize: '12px', overflowX: 'auto', marginBottom: '20px' }}>
              {this.state.error?.toString() || "Unknown Error"}
            </div>
            <button onClick={() => window.location.reload()} style={{ backgroundColor: '#e11d48', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}>
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Types ---
type UserAccess = {
  id: number;
  email: string;
  full_name: string | null;      
  user_password: string | null;  
  is_active: boolean;
  device_id: string | null;
  created_at: string;
  expires_at: string | null;
};

type PlatformItem = {
  id: number;
  name: string;
  icon_url: string;
  is_hidden?: boolean;
};

type AIModel = {
  id: number;
  provider_id: string;
  provider_name: string;
  api_url: string;
  model_name: string;
  priority: number;
  is_active: boolean;
};

type AppSettings = {
  update_notice: string;
  notice_link: string;
  is_maintenance: boolean;
  upcoming_platforms: PlatformItem[];
};

// ==========================================
// CORE APP COMPONENT
// ==========================================
const MainApp = () => {
  const [isMounted, setIsMounted] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  // --- View States ---
  const [currentView, setCurrentView] = useState<'home' | 'demo' | 'login' | 'admin'>('home');
  const [adminTab, setAdminTab] = useState<'content' | 'users' | 'settings'>('content');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // --- Dynamic Content State ---
  const [siteData, setSiteData] = useState({
    logoImage: "", 
    mockupLogo: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Adobe_Stock_icon.svg/512px-Adobe_Stock_icon.svg.png", 
    extensionIcon: "", 
    supportKoriLink: "https://www.supportkori.com/mohammadraihan/extras/adobe-stock-sutterstock-auto-tag-title-automation-xfih",
    iframeCropMobile: 12, 
    iframeCropDesktop: 15, 
    iframeZoomMobile: 100, 
    iframeZoomDesktop: 100, 
    banners: [
      { id: 1, image: "https://via.placeholder.com/1600x900/fff/FCE34D?text=16:9+Banner+1", title: "অটোমেটিক মেটাডাটা জেনারেট", desc: "এআই দ্বারা ইমেজের টাইটেল ও ট্যাগ জেনারেট হবে।" }
    ],
    products: [
      { id: 1, image: "https://via.placeholder.com/400x400/f8fafc/FCE34D?text=Pro+License", title: "Raihan Metadata Pro (Lifetime)", price: "৳ ১৪২৮", desc: "একটি লাইসেন্স শুধুমাত্র একটি পিসিতেই ব্যবহারযোগ্য, যা আপনার একাউন্টকে রাখে সম্পূর্ণ নিরাপদ।" }
    ]
  });

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);

  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [paperRotations, setPaperRotations] = useState<number[]>([]);

  // --- USERS MANAGEMENT STATE ---
  const [usersList, setUsersList] = useState<UserAccess[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);

  // --- SUBSCRIPTION MODAL STATE ---
  const [isSubModalOpen, setIsSubModalOpen] = useState(false);
  const [subTargetAction, setSubTargetAction] = useState<'single' | 'bulk'>('single');
  const [subTargetId, setSubTargetId] = useState<number | null>(null);
  const [selectedDuration, setSelectedDuration] = useState<number | null>(1);

  // --- APP SETTINGS STATE ---
  const [appSettings, setAppSettings] = useState<AppSettings>({
    update_notice: '',
    notice_link: '',
    is_maintenance: false,
    upcoming_platforms: []
  });
  
  // --- AI MODELS STATE ---
  const [aiModels, setAiModels] = useState<AIModel[]>([]);
  const [isLoadingModels, setIsLoadingModels] = useState(false);
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // --- INTERACTIVE DEMO STATES ---
  const [demoImages, setDemoImages] = useState<{url: string, name: string}[]>([]);
  const [selectedDemoImage, setSelectedDemoImage] = useState<number | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showExtension, setShowExtension] = useState(false);
  const [isGeneratingDemo, setIsGeneratingDemo] = useState(false);
  const [demoTitle, setDemoTitle] = useState("");
  const [demoTags, setDemoTags] = useState("");
  const [isMetadataFilled, setIsMetadataFilled] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessingImages, setIsProcessingImages] = useState(false);

  const [uploadToast, setUploadToast] = useState({ show: false, progress: 0, message: '' });

  // Safe Arrays
  const safeBanners = Array.isArray(siteData?.banners) ? siteData.banners : [];
  const safeProducts = Array.isArray(siteData?.products) ? siteData.products : [];
  const safeUsersList = Array.isArray(usersList) ? usersList : [];
  const safeDemoImages = Array.isArray(demoImages) ? demoImages : [];
  const safePlatforms = Array.isArray(appSettings?.upcoming_platforms) ? appSettings.upcoming_platforms : [];
  const safeModels = Array.isArray(aiModels) ? aiModels : [];

  // Initial Data Load
  useEffect(() => {
    setIsMounted(true);
    
    if (typeof document !== 'undefined') {
      try {
        let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
        if (!link) {
          link = document.createElement('link');
          link.rel = 'icon';
          document.head.appendChild(link);
        }
        link.href = 'https://gfjqjislhsnttsscytza.supabase.co/storage/v1/object/public/favicon/icon16.png';
      } catch (e) {
        console.error("Favicon set error:", e);
      }
    }

    const fetchSiteData = async () => {
      try {
        if (!supabase) return;
        const { data } = await supabase.from('site_settings').select('data').eq('id', 1).maybeSingle();
        if (data && data.data && typeof data.data === 'object') {
          setSiteData(prev => ({ 
            ...prev, 
            ...data.data,
            banners: Array.isArray(data.data.banners) ? data.data.banners : prev.banners,
            products: Array.isArray(data.data.products) ? data.data.products : prev.products,
            mockupLogo: data.data.mockupLogo || prev.mockupLogo,
            extensionIcon: data.data.extensionIcon || prev.extensionIcon,
            iframeCropMobile: data.data.iframeCropMobile ?? 12,
            iframeCropDesktop: data.data.iframeCropDesktop ?? 15,
            iframeZoomMobile: data.data.iframeZoomMobile ?? 100,
            iframeZoomDesktop: data.data.iframeZoomDesktop ?? 100
          }));
          const bannerArr = Array.isArray(data.data.banners) ? data.data.banners : [];
          setPaperRotations(bannerArr.map(() => Math.random() * 6 - 3));
        }
      } catch (err) {
        console.error("Error fetching site data:", err);
      } finally {
        setTimeout(() => setIsDataLoaded(true), 300);
      }
    };
    fetchSiteData();
  }, []);

  // Banner Auto-Rotation
  useEffect(() => {
    if (currentView === 'home' && safeBanners.length > 0) {
      const interval = setInterval(() => {
        setActiveBannerIndex((prev) => (prev + 1) % safeBanners.length);
      }, 3500); 
      return () => clearInterval(interval);
    }
  }, [currentView, safeBanners.length]);

  // Admin Data Fetching
  useEffect(() => {
    if (currentView === 'admin') {
      if (adminTab === 'settings') {
        fetchAppSettings();
        fetchAiModels();
      }
      if (adminTab === 'users') fetchExtensionUsers();
    }
  }, [currentView, adminTab]);

  const fetchAppSettings = async () => {
    if (!supabase) return;
    try {
      const { data } = await supabase.from('app_settings').select('*').eq('id', 1).maybeSingle();
      if (data) {
        let parsedPlatforms = [];
        try {
          if (typeof data.upcoming_platforms === 'string') parsedPlatforms = JSON.parse(data.upcoming_platforms);
          else if (Array.isArray(data.upcoming_platforms)) parsedPlatforms = data.upcoming_platforms;
        } catch(e) { parsedPlatforms = []; }

        setAppSettings({
          update_notice: data.update_notice || '',
          notice_link: data.notice_link || '',
          is_maintenance: data.is_maintenance || false,
          upcoming_platforms: Array.isArray(parsedPlatforms) ? parsedPlatforms : []
        });
      }
    } catch (err) {
      console.error("Error fetching settings", err);
    }
  };

  const fetchAiModels = async () => {
    if (!supabase) return;
    setIsLoadingModels(true);
    try {
      const { data, error } = await supabase.from('ai_models').select('*').order('priority', { ascending: true });
      if (!error && data) setAiModels(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingModels(false);
    }
  };

  const fetchExtensionUsers = async () => {
    if (!supabase) return;
    setIsLoadingUsers(true);
    setSelectedUsers([]);
    try {
      const { data, error } = await supabase.from('users_access').select('*').order('created_at', { ascending: false });
      if (!error && data && Array.isArray(data)) setUsersList(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  // --- SAVE SETTINGS & MODELS ---
  const handleSaveAppSettings = async () => {
    if (!supabase) return;
    setIsSavingSettings(true);
    try {
      const payloadToSave = { 
        id: 1, 
        update_notice: appSettings.update_notice,
        notice_link: appSettings.notice_link,
        is_maintenance: appSettings.is_maintenance,
        upcoming_platforms: appSettings.upcoming_platforms
      };
      const { error: settingsError } = await supabase.from('app_settings').upsert(payloadToSave);
      if (settingsError) throw settingsError;

      for (const model of safeModels) {
        if (!model) continue;
        const payload = { ...model };
        if (payload.id > 1000000000) {
          delete (payload as any).id;
        }
        const { error: modelError } = await supabase.from('ai_models').upsert(payload);
        if (modelError) throw modelError;
      }

      setUploadToast({ show: true, progress: 100, message: 'Settings Saved! ✅' });
      setTimeout(() => setUploadToast({ show: false, progress: 0, message: '' }), 2000);
      
      fetchAiModels();
    } catch (err: any) {
      alert("Error: " + err.message);
    } finally {
      setIsSavingSettings(false);
    }
  };

  // --- DYNAMIC AI MODELS LOGIC ---
  const handleAddAiModel = () => {
    const newPriority = safeModels.length > 0 ? Math.max(...safeModels.map(m => m ? m.priority || 0 : 0)) + 1 : 1;
    setAiModels([
      ...safeModels, 
      { id: Date.now(), provider_id: '', provider_name: '', api_url: '', model_name: '', priority: newPriority, is_active: false }
    ]);
  };

  const handleUpdateAiModel = (id: number, key: keyof AIModel, value: any) => {
    setAiModels(safeModels.map(m => {
      if (!m) return m;
      if (m.id === id) return { ...m, [key]: value };
      return m;
    }));
  };

  const handleRemoveAiModel = async (id: number) => {
    if(!window.confirm("Delete this model routing?")) return;
    try {
      if (id < 1000000000 && supabase) {
        await supabase.from('ai_models').delete().eq('id', id);
      }
      setAiModels(safeModels.filter(m => m && m.id !== id));
    } catch(e) { console.error(e); }
  };

  // --- DYNAMIC PLATFORMS LOGIC ---
  const handleAddPlatform = () => {
    setAppSettings(prev => ({
      ...prev,
      upcoming_platforms: [...safePlatforms, { id: Date.now(), name: '', icon_url: '', is_hidden: false }]
    }));
  };

  const handleUpdatePlatform = (id: number, key: 'name' | 'icon_url', value: string) => {
    setAppSettings(prev => ({
      ...prev,
      upcoming_platforms: safePlatforms.map(p => {
        if (!p) return p;
        if (p.id === id) return { ...p, [key]: value };
        return p;
      })
    }));
  };

  const handleTogglePlatformVisibility = (id: number) => {
    setAppSettings(prev => ({
      ...prev,
      upcoming_platforms: safePlatforms.map(p => {
        if (!p) return p;
        if (p.id === id) return { ...p, is_hidden: !p.is_hidden };
        return p;
      })
    }));
  };

  const handleRemovePlatform = (id: number) => {
    setAppSettings(prev => ({
      ...prev,
      upcoming_platforms: safePlatforms.filter(p => p && p.id !== id)
    }));
  };

  const handlePlatformIconUpload = async (e: React.ChangeEvent<HTMLInputElement>, platformId: number) => {
    if (!e.target.files?.[0]) return;
    const url = await uploadToCloudinary(e.target.files[0]);
    if (url) handleUpdatePlatform(platformId, 'icon_url', url);
  };

  // Subscription Logic
  const calculateExpiryDate = (months: number | null): string | null => {
    if (months === null) return null; 
    const d = new Date();
    d.setMonth(d.getMonth() + months);
    return d.toISOString();
  };

  const formatExpiryUI = (dateString: string | null) => {
    if (!dateString) return <span className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded text-[9px] font-bold border border-emerald-500/20 flex items-center w-fit gap-1"><span>♾️</span> Lifetime</span>;
    const expiryDate = new Date(dateString);
    if (isNaN(expiryDate.getTime())) return <span className="text-rose-500 dark:text-rose-400 text-[10px]">Invalid Date</span>;
    if (expiryDate < new Date()) return <span className="bg-rose-500/10 text-rose-600 dark:text-rose-400 px-2 py-0.5 rounded text-[9px] font-bold border border-rose-500/20 flex items-center w-fit gap-1"><span>⏳</span> Expired</span>;
    return <span className="text-slate-700 dark:text-slate-300 text-[10px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 flex items-center w-fit gap-1.5"><span>📅</span> {expiryDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>;
  };

  const openSubscriptionModal = (type: 'single' | 'bulk', id?: number) => {
    setSubTargetAction(type);
    if (type === 'single' && id) setSubTargetId(id);
    setIsSubModalOpen(true);
  };

  const confirmSubscriptionAction = async () => {
    if (!supabase) return;
    const expiresAt = calculateExpiryDate(selectedDuration);
    const updates = { is_active: true, expires_at: expiresAt };
    setIsLoadingUsers(true);
    try {
      if (subTargetAction === 'single' && subTargetId) {
        await supabase.from('users_access').update(updates).eq('id', subTargetId);
        setUsersList(prev => prev.map(u => {
          if (!u) return u;
          if (u.id === subTargetId) return { ...u, ...updates };
          return u;
        }));
      } else if (subTargetAction === 'bulk' && selectedUsers.length > 0) {
        await supabase.from('users_access').update(updates).in('id', selectedUsers);
        setUsersList(prev => prev.map(u => {
          if (!u) return u;
          if (selectedUsers.includes(u.id)) return { ...u, ...updates };
          return u;
        }));
        setSelectedUsers([]);
      }
      setIsSubModalOpen(false);
      setUploadToast({ show: true, progress: 100, message: 'Subscription Activated! 🎉' });
      setTimeout(() => setUploadToast({ show: false, progress: 0, message: '' }), 2000);
    } catch (err: any) {
      alert("Error applying subscription: " + err.message);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  const handleUserAction = async (id: number, action: 'revoke' | 'reset') => {
    if (!supabase) return;
    let updates = {};
    if (action === 'revoke') updates = { is_active: false }; 
    if (action === 'reset') updates = { device_id: null };
    try {
      await supabase.from('users_access').update(updates).eq('id', id);
      setUsersList(prev => prev.map(u => {
        if (!u) return u;
        if (u.id === id) return { ...u, ...updates };
        return u;
      }));
    } catch (err) { console.error(err); }
  };

  const handleDeleteUser = async (id: number) => {
    if (!supabase) return;
    if (!window.confirm("Permanently delete user?")) return;
    try {
      await supabase.from('users_access').delete().eq('id', id);
      setUsersList(prev => prev.filter(u => u && u.id !== id));
      setSelectedUsers(prev => prev.filter(selectedId => selectedId !== id));
    } catch (err) { console.error(err); }
  };

  const handleBulkAction = async (action: 'revoke' | 'delete') => {
    if (!supabase) return;
    if (selectedUsers.length === 0) return;
    if (action === 'delete' && !window.confirm(`Delete ${selectedUsers.length} users?`)) return;
    setIsLoadingUsers(true);
    try {
      if (action === 'delete') {
        await supabase.from('users_access').delete().in('id', selectedUsers);
        setUsersList(prev => prev.filter(u => u && !selectedUsers.includes(u.id)));
      } else if (action === 'revoke') {
        await supabase.from('users_access').update({ is_active: false }).in('id', selectedUsers);
        setUsersList(prev => prev.map(u => {
          if (!u) return u;
          if (selectedUsers.includes(u.id)) return { ...u, is_active: false };
          return u;
        }));
      }
      setSelectedUsers([]); 
    } catch (err) { console.error(err); } finally { setIsLoadingUsers(false); }
  };

  const handleToggleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) setSelectedUsers(safeUsersList.filter(u => u).map(u => u.id));
    else setSelectedUsers([]);
  };

  const handleToggleSelect = (id: number) => {
    setSelectedUsers(prev => prev.includes(id) ? prev.filter(userId => userId !== id) : [...prev, id]);
  };

  const handleAdminAccess = () => {
    if (typeof window !== 'undefined') {
      setCurrentView(localStorage.getItem('isAdminLoggedIn') === 'true' ? 'admin' : 'login');
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'mohammadraihan4386.bd@gmail.com' && password === 'admin123') {
      if (typeof window !== 'undefined') localStorage.setItem('isAdminLoggedIn', 'true');
      setCurrentView('admin');
      setLoginError(''); setEmail(''); setPassword('');
    } else {
      setLoginError('Invalid credentials');
    }
  };

  const handleLogout = () => {
    if (typeof window !== 'undefined') localStorage.removeItem('isAdminLoggedIn');
    setCurrentView('home');
  };

  const uploadToCloudinary = (file: File): Promise<string | null> => {
    return new Promise((resolve) => {
      setUploadToast({ show: true, progress: 0, message: 'Uploading...' });
      const formData = new FormData();
      formData.append('file', file);
      formData.append('upload_preset', UPLOAD_PRESET);
      const xhr = new XMLHttpRequest();
      xhr.open('POST', `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) setUploadToast({ show: true, progress: Math.round((e.loaded / e.total) * 100), message: `Uploading... ${Math.round((e.loaded / e.total) * 100)}%` });
      };
      xhr.onload = () => {
        if (xhr.status === 200) {
          setUploadToast({ show: true, progress: 100, message: 'Complete! ✅' });
          setTimeout(() => setUploadToast({ show: false, progress: 0, message: '' }), 2000);
          resolve(JSON.parse(xhr.responseText).secure_url);
        } else {
          setUploadToast({ show: true, progress: 0, message: 'Failed ❌' });
          setTimeout(() => setUploadToast({ show: false, progress: 0, message: '' }), 2000);
          resolve(null);
        }
      };
      xhr.onerror = () => resolve(null);
      xhr.send(formData);
    });
  };

  const handleSave = async () => {
    if (!supabase) return;
    setIsSaving(true);
    const { error } = await supabase.from('site_settings').upsert({ id: 1, data: siteData });
    setIsSaving(false);
    if (!error) {
      setSaveSuccess(true); setHasUnsavedChanges(false);
      setTimeout(() => setSaveSuccess(false), 2000);
    }
  };

  const updateSiteData = (newData: typeof siteData) => {
    setSiteData(newData); setHasUnsavedChanges(true);
  };

  const handleDemoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    setIsProcessingImages(true);
    const files = Array.from(e.target.files).slice(0, 10);
    const processedImages: {url: string, name: string}[] = [];
    for (const file of files) {
      try {
        if (typeof window !== 'undefined') await new Promise(r => requestAnimationFrame(r));
        const compressedUrl = await compressImageForDemo(file);
        processedImages.push({ url: compressedUrl, name: file.name });
      } catch (err) {
        processedImages.push({ url: URL.createObjectURL(file), name: file.name });
      }
    }
    setDemoImages(prev => {
       const oldImages = Array.isArray(prev) ? prev : [];
       return [...oldImages, ...processedImages].slice(-15);
    });
    if (selectedDemoImage === null) setSelectedDemoImage(0);
    setShowUploadModal(false);
    setIsProcessingImages(false);
    setIsMetadataFilled(false); 
    setDemoTitle(""); setDemoTags("");
  };

  const compressImageForDemo = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        const canvas = document.createElement('canvas');
        let { width, height } = img;
        if (width > height && width > 600) { height = Math.round((height * 600) / width); width = 600; } 
        else if (height > 600) { width = Math.round((width * 600) / height); height = 600; }
        canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: true });
        if(!ctx) return reject('No context');
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob((blob) => {
          if (blob) resolve(URL.createObjectURL(blob)); else reject(new Error('Failed'));
        }, 'image/jpeg', 0.6);
      };
      img.onerror = () => reject(new Error('Failed'));
      img.src = objectUrl;
    });
  };

  const handleGenerateDemoMetadata = () => {
    if(safeDemoImages.length === 0) return alert("Upload an image first.");
    setIsGeneratingDemo(true);
    setTimeout(() => {
      setDemoTitle("Beautiful natural landscape with amazing scenic sunset and mountains");
      setDemoTags("nature, landscape, sunset, mountains, sky, beautiful, outdoor, scenic, summer, background, travel, view, light, sun, water, lake, reflection, evening, colorful, silhouette");
      setIsGeneratingDemo(false); setIsMetadataFilled(true); 
    }, 800); 
  };

  // ==========================================
  // RENDER FUNCTIONS
  // ==========================================

  if (!isMounted) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#020617] flex flex-col items-center justify-center relative z-10">
        <div className="w-12 h-12 border-4 rounded-full animate-spin mb-4 border-blue-200 border-t-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.3)]"></div>
      </div>
    );
  }

  const renderAdminDashboard = () => (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#020617] text-slate-300 bg-grid-pattern-dark' : 'bg-slate-50 text-slate-900 bg-grid-pattern-light'} p-2 sm:p-4 md:p-8 overflow-y-auto font-sans pb-32 hardware-accelerated relative z-10 transition-colors duration-500`}>
      <div className="max-w-[1200px] mx-auto flex justify-end mb-4">
        <button onClick={toggleTheme} className={`p-2 rounded-full shadow-md border transition-colors ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100'}`}>
          {theme === 'light' ? <span>🌙</span> : <span>☀️</span>}
        </button>
      </div>

      <div className={`max-w-[1200px] mx-auto backdrop-blur-xl border rounded-2xl md:rounded-3xl p-4 sm:p-5 md:p-8 shadow-2xl transition-colors duration-500 ${theme === 'dark' ? 'bg-slate-900/80 border-slate-800' : 'bg-white/90 border-slate-200'}`}>
        <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 md:mb-8 border-b pb-4 gap-4 ${theme === 'dark' ? 'border-slate-800' : 'border-slate-200'}`}>
          <h2 className={`text-xl md:text-3xl font-extrabold flex items-center gap-2 md:gap-3 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>🛡️</span> System Dashboard</h2>
          <div className="flex w-full sm:w-auto gap-2">
            <button onClick={() => setCurrentView('home')} className={`btn-smooth flex-1 sm:flex-none px-4 py-2.5 rounded-xl text-sm font-semibold border text-center ${theme === 'dark' ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700' : 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200'}`}>Exit Site</button>
            <button onClick={handleLogout} className={`btn-smooth flex-1 sm:flex-none px-4 py-2.5 rounded-xl text-sm font-semibold border flex items-center justify-center gap-1.5 ${theme === 'dark' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 hover:bg-rose-500/20' : 'bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100'}`}><span>🚪</span> Logout</button>
          </div>
        </div>

        <div className={`grid grid-cols-1 sm:grid-cols-3 gap-2 mb-6 md:mb-8 p-2 rounded-xl w-full shadow-inner border max-w-3xl ${theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
           <button onClick={() => setAdminTab('content')} className={`btn-smooth py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 ${adminTab === 'content' ? (theme === 'dark' ? 'bg-slate-800 shadow-md text-white border border-slate-700' : 'bg-white shadow-md text-slate-900 border border-slate-300') : (theme === 'dark' ? 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200')}`}><span>✏️</span> Content Manager</button>
           <button onClick={() => setAdminTab('users')} className={`btn-smooth py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 ${adminTab === 'users' ? (theme === 'dark' ? 'bg-slate-800 shadow-md text-white border border-slate-700' : 'bg-white shadow-md text-slate-900 border border-slate-300') : (theme === 'dark' ? 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200')}`}><span>👥</span> Access Control</button>
           <button onClick={() => setAdminTab('settings')} className={`btn-smooth py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 ${adminTab === 'settings' ? (theme === 'dark' ? 'bg-slate-800 shadow-md text-white border border-slate-700' : 'bg-white shadow-md text-slate-900 border border-slate-300') : (theme === 'dark' ? 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200')}`}><span>⚙️</span> App Settings</button>
        </div>

        {/* ADMIN TAB: CONTENT */}
        {adminTab === 'content' && (
          <div className="animate-fade-in-up">
            <div className={`space-y-4 mb-6 md:mb-8 p-4 md:p-6 rounded-xl md:rounded-2xl border ${theme === 'dark' ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <h3 className={`text-base md:text-xl font-bold mb-4 flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>🛒</span> Global Settings &amp; Logos</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4 md:mb-6">
                 <div className={`flex flex-col items-center p-3 md:p-4 rounded-xl border text-center hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
                   {siteData?.logoImage ? <img src={siteData.logoImage} alt="Main Logo" className={`w-12 h-12 md:w-14 md:h-14 rounded-full border object-cover mb-2 ${theme === 'dark' ? 'border-slate-600' : 'border-slate-300'}`} decoding="async" /> : <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center border font-bold mb-2 ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-200 border-slate-300 text-slate-900'}`}>RM</div>}
                    <label className={`block text-xs mb-2 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Main Website Logo</label>
                    <label className={`btn-smooth inline-block w-full px-3 py-2 rounded-lg cursor-pointer active:scale-95 text-xs font-bold ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border border-[#00d4ff]/30 hover:bg-[#00d4ff]/20' : 'bg-blue-100 text-blue-600 border border-blue-200 hover:bg-blue-200'}`}><input type="file" className="hidden" accept="image/*" onChange={async (e) => { if(e.target.files?.[0]) { const url = await uploadToCloudinary(e.target.files[0]); if(url) updateSiteData({...siteData, logoImage: url}); } }}/>Upload Logo</label>
                 </div>
                 <div className={`flex flex-col items-center p-3 md:p-4 rounded-xl border text-center hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
                   {siteData?.mockupLogo ? <img src={siteData.mockupLogo} alt="Mockup Logo" className={`w-12 h-12 md:w-14 md:h-14 rounded-full border object-contain p-1 mb-2 ${theme === 'dark' ? 'border-slate-600 bg-white' : 'border-slate-300 bg-slate-50'}`} decoding="async" /> : <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center border font-bold mb-2 ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-200 border-slate-300 text-slate-900'}`}>St</div>}
                    <label className={`block text-xs mb-2 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Demo Mockup Logo</label>
                    <label className={`btn-smooth inline-block w-full px-3 py-2 rounded-lg cursor-pointer text-xs font-bold border ${theme === 'dark' ? 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'}`}><input type="file" className="hidden" accept="image/*" onChange={async (e) => { if(e.target.files?.[0]) { const url = await uploadToCloudinary(e.target.files[0]); if(url) updateSiteData({...siteData, mockupLogo: url}); } }}/>Upload Mockup</label>
                 </div>
                 <div className={`flex flex-col items-center p-3 md:p-4 rounded-xl border text-center hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
                   {siteData?.extensionIcon ? <img src={siteData.extensionIcon} alt="Ext Icon" className={`w-12 h-12 md:w-14 md:h-14 rounded-full border object-contain p-1 mb-2 ${theme === 'dark' ? 'border-slate-600' : 'border-slate-300'}`} decoding="async" /> : <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center border font-bold mb-2 ${theme === 'dark' ? 'bg-red-600/20 border-red-500/50 text-red-400' : 'bg-red-100 border-red-300 text-red-600'}`}>MR</div>}
                    <label className={`block text-xs mb-2 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Extension Icon</label>
                    <label className={`btn-smooth inline-block w-full px-3 py-2 rounded-lg cursor-pointer text-xs font-bold border ${theme === 'dark' ? 'bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'}`}><input type="file" className="hidden" accept="image/*" onChange={async (e) => { if(e.target.files?.[0]) { const url = await uploadToCloudinary(e.target.files[0]); if(url) updateSiteData({...siteData, extensionIcon: url}); } }}/>Upload Icon</label>
                 </div>
              </div>
              <div>
                <label className={`block text-xs md:text-sm mb-1 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>SupportKori URL (For Buy Buttons)</label>
                <input type="text" value={siteData?.supportKoriLink || ''} onChange={(e) => updateSiteData({...siteData, supportKoriLink: e.target.value})} className={`input-smooth w-full p-3 border rounded-xl text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`}/>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4 pt-2">
                <div><label className={`block text-xs md:text-sm mb-1 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Mobile Crop</label><input type="number" value={siteData?.iframeCropMobile || 0} onChange={(e) => updateSiteData({...siteData, iframeCropMobile: Number(e.target.value)})} className={`input-smooth w-full p-3 border rounded-xl text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`}/></div>
                <div><label className={`block text-xs md:text-sm mb-1 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Mobile Zoom</label><input type="number" value={siteData?.iframeZoomMobile || 0} onChange={(e) => updateSiteData({...siteData, iframeZoomMobile: Number(e.target.value)})} className={`input-smooth w-full p-3 border rounded-xl text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`}/></div>
                <div><label className={`block text-xs md:text-sm mb-1 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Desktop Crop</label><input type="number" value={siteData?.iframeCropDesktop || 0} onChange={(e) => updateSiteData({...siteData, iframeCropDesktop: Number(e.target.value)})} className={`input-smooth w-full p-3 border rounded-xl text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`}/></div>
                <div><label className={`block text-xs md:text-sm mb-1 font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Desktop Zoom</label><input type="number" value={siteData?.iframeZoomDesktop || 0} onChange={(e) => updateSiteData({...siteData, iframeZoomDesktop: Number(e.target.value)})} className={`input-smooth w-full p-3 border rounded-xl text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`}/></div>
              </div>
            </div>

            <div className={`mb-6 md:mb-8 p-4 md:p-6 rounded-xl md:rounded-2xl border ${theme === 'dark' ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <h3 className={`text-base md:text-xl font-bold mb-4 flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>📑</span> Hero Banners (16:9)</h3>
              {safeBanners.map((banner, index) => {
                if (!banner) return null;
                return (
                <div key={banner.id || index} className={`p-3 md:p-4 rounded-xl mb-4 flex flex-col md:flex-row gap-3 md:gap-4 border hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
                  <img src={banner.image || ''} alt="banner" className={`w-full md:w-32 h-32 md:h-auto aspect-video object-cover rounded-md border ${theme === 'dark' ? 'border-slate-700' : 'border-slate-200'}`} decoding="async" loading="lazy" />
                  <div className="flex-1 space-y-2 w-full">
                    <input type="text" value={banner.title || ''} onChange={(e) => { const b = [...safeBanners]; b[index] = {...b[index], title: e.target.value}; updateSiteData({...siteData, banners: b}); }} className={`input-smooth w-full p-2.5 border rounded-lg text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-800 border-slate-600 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}/>
                    <textarea value={banner.desc || ''} onChange={(e) => { const b = [...safeBanners]; b[index] = {...b[index], desc: e.target.value}; updateSiteData({...siteData, banners: b}); }} className={`input-smooth w-full p-2.5 border rounded-lg text-xs md:text-sm font-bangla h-16 resize-none ${theme === 'dark' ? 'bg-slate-800 border-slate-600 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}/>
                    <div className="flex gap-2">
                      <label className={`btn-smooth flex-1 text-center py-2 rounded-lg cursor-pointer text-xs font-bold border ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30 hover:bg-[#00d4ff]/20' : 'bg-blue-100 text-blue-600 border-blue-200 hover:bg-blue-200'}`}><input type="file" className="hidden" accept="image/*" onChange={async (e) => { if(e.target.files?.[0]) { const url = await uploadToCloudinary(e.target.files[0]); if(url) { const b = [...safeBanners]; b[index] = {...b[index], image: url}; updateSiteData({...siteData, banners: b}); } } }}/>Change Image</label>
                      <button onClick={() => updateSiteData({...siteData, banners: safeBanners.filter(b => b && b.id !== banner.id)})} className={`btn-smooth px-4 rounded-lg border ${theme === 'dark' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 hover:bg-rose-500/20' : 'bg-rose-100 text-rose-600 border-rose-200 hover:bg-rose-200'}`}><span>🗑️</span></button>
                    </div>
                  </div>
                </div>
              )})}
              <button onClick={() => updateSiteData({...siteData, banners: [...safeBanners, { id: Date.now(), image: "https://via.placeholder.com/1600x900/e2e8f0/3b82f6?text=New+Banner", title: "New Title", desc: "New Description" }]})} className={`btn-smooth w-full py-3 border rounded-xl flex items-center justify-center gap-2 text-xs md:text-sm font-bold ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700' : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'}`}><span>➕</span> Add New Banner</button>
            </div>

            <div className={`p-4 md:p-6 rounded-xl md:rounded-2xl border ${theme === 'dark' ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <h3 className={`text-base md:text-xl font-bold mb-4 flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>🛒</span> Products Section</h3>
              {safeProducts.map((product, index) => {
                if (!product) return null;
                return (
                <div key={product.id || index} className={`p-3 md:p-4 rounded-xl mb-4 flex flex-col md:flex-row gap-3 md:gap-4 border hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
                  <img src={product.image || ''} alt="product" className={`w-full md:w-32 h-40 md:h-32 object-cover rounded-md shadow-sm border ${theme === 'dark' ? 'border-slate-700' : 'border-slate-200'}`} decoding="async" loading="lazy" />
                  <div className="flex-1 space-y-2 w-full">
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input type="text" value={product.title || ''} onChange={(e) => { const p = [...safeProducts]; p[index] = {...p[index], title: e.target.value}; updateSiteData({...siteData, products: p}); }} className={`input-smooth flex-1 p-2.5 border rounded-lg text-xs md:text-sm ${theme === 'dark' ? 'bg-slate-800 border-slate-600 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}/>
                      <input type="text" value={product.price || ''} onChange={(e) => { const p = [...safeProducts]; p[index] = {...p[index], price: e.target.value}; updateSiteData({...siteData, products: p}); }} className={`input-smooth w-full sm:w-28 p-2.5 border rounded-lg text-xs md:text-sm font-bangla font-bold ${theme === 'dark' ? 'bg-slate-800 border-slate-600 text-[#00d4ff]' : 'bg-slate-50 border-slate-300 text-blue-600'}`}/>
                    </div>
                    <textarea value={product.desc || ''} onChange={(e) => { const p = [...safeProducts]; p[index] = {...p[index], desc: e.target.value}; updateSiteData({...siteData, products: p}); }} className={`input-smooth w-full p-2.5 border rounded-lg text-xs md:text-sm font-bangla h-16 resize-none ${theme === 'dark' ? 'bg-slate-800 border-slate-600 text-slate-300' : 'bg-slate-50 border-slate-300 text-slate-700'}`}/>
                    <label className={`btn-smooth block w-full text-center py-2.5 rounded-lg cursor-pointer text-xs md:text-sm font-semibold border ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30 hover:bg-[#00d4ff]/20' : 'bg-blue-100 text-blue-600 border-blue-200 hover:bg-blue-200'}`}><input type="file" className="hidden" accept="image/*" onChange={async (e) => { if(e.target.files?.[0]) { const url = await uploadToCloudinary(e.target.files[0]); if(url) { const p = [...safeProducts]; p[index] = {...p[index], image: url}; updateSiteData({...siteData, products: p}); } } }}/>Change Product Image</label>
                  </div>
                </div>
              )})}
            </div>
          </div>
        )}

        {/* ADMIN TAB: USERS */}
        {adminTab === 'users' && (
          <div className={`p-3 md:p-6 rounded-2xl shadow-xl dark:shadow-2xl border animate-fade-in-up ${theme === 'dark' ? 'bg-slate-800/50 border-slate-700' : 'bg-white border-slate-200'}`}>
            <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 border-b pb-4 gap-3 ${theme === 'dark' ? 'border-slate-700' : 'border-slate-200'}`}>
              <div>
                 <h3 className={`text-lg md:text-xl font-bold flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>👥</span> Active Subscriptions</h3>
                 <p className={`text-[10px] md:text-xs mt-1 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>Manage extension access, subscriptions, and device IDs.</p>
              </div>
              <div className="flex w-full sm:w-auto gap-2 flex-wrap">
                {selectedUsers.length > 0 && (
                  <>
                    <button onClick={() => openSubscriptionModal('bulk')} className={`btn-smooth px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 border ${theme === 'dark' ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/30' : 'bg-emerald-100 text-emerald-700 border-emerald-300'}`}><span>📅</span> Approve ({selectedUsers.length})</button>
                    <button onClick={() => handleBulkAction('revoke')} className={`btn-smooth px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 border ${theme === 'dark' ? 'bg-amber-600/20 text-amber-400 border-amber-500/30' : 'bg-amber-100 text-amber-700 border-amber-300'}`}><span>🚫</span> Revoke ({selectedUsers.length})</button>
                    <button onClick={() => handleBulkAction('delete')} className={`btn-smooth px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 border ${theme === 'dark' ? 'bg-rose-600/20 text-rose-400 border-rose-500/30' : 'bg-rose-100 text-rose-700 border-rose-300'}`}><span>🗑️</span> Delete ({selectedUsers.length})</button>
                  </>
                )}
                <button onClick={fetchExtensionUsers} className={`btn-smooth flex-1 sm:flex-none justify-center px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 border ${theme === 'dark' ? 'bg-slate-700 text-white border-slate-600 hover:bg-slate-600' : 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200'}`}><span>🔄</span> Refresh</button>
              </div>
            </div>
            <div className={`overflow-x-auto rounded-xl border custom-scrollbar ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <table className="w-full text-left border-collapse min-w-[750px]">
                <thead>
                  <tr className={`text-[10px] md:text-xs uppercase tracking-wider border-b ${theme === 'dark' ? 'bg-slate-800 text-slate-300 border-slate-700' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                    <th className="p-3 w-10 text-center"><input type="checkbox" className={`cursor-pointer ${theme === 'dark' ? 'accent-[#00d4ff]' : 'accent-blue-600'}`} checked={safeUsersList.length > 0 && selectedUsers.length === safeUsersList.length} onChange={handleToggleSelectAll}/></th>
                    <th className="p-3 font-semibold">User Info</th>
                    <th className="p-3 font-semibold">Status</th>
                    <th className="p-3 font-semibold">Expiry Date</th>
                    <th className="p-3 font-semibold">Device ID</th>
                    <th className="p-3 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-800' : 'divide-slate-200'}`}>
                  {isLoadingUsers ? (<tr><td colSpan={6} className="p-6 text-center text-slate-500 text-xs">Loading users...</td></tr>) : safeUsersList.length === 0 ? (<tr><td colSpan={6} className="p-6 text-center text-slate-500 text-xs">No users found in database.</td></tr>) : (
                    safeUsersList.map(user => {
                       if (!user) return null;
                       const isExpired = user.expires_at && !isNaN(new Date(user.expires_at).getTime()) && new Date(user.expires_at) < new Date();
                       const statusColor = user.is_active && !isExpired ? (theme === 'dark' ? 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10' : 'text-emerald-700 border-emerald-300 bg-emerald-100') : (theme === 'dark' ? 'text-rose-400 border-rose-500/30 bg-rose-500/10' : 'text-rose-700 border-rose-300 bg-rose-100');
                       return (
                        <tr key={user.id} className={`transition-colors smooth-hover ${selectedUsers.includes(user.id) ? (theme === 'dark' ? 'bg-slate-800' : 'bg-slate-100') : (theme === 'dark' ? 'hover:bg-slate-800/80' : 'hover:bg-slate-100')}`}>
                          <td className="p-3 text-center"><input type="checkbox" className={`cursor-pointer ${theme === 'dark' ? 'accent-[#00d4ff]' : 'accent-blue-600'}`} checked={selectedUsers.includes(user.id)} onChange={() => handleToggleSelect(user.id)}/></td>
                          <td className="p-3">
                            <div className="flex flex-col gap-1">
                              <div className="flex items-center gap-2">
                                <span className={`text-xs font-bold ${user.full_name ? (theme === 'dark' ? 'text-slate-200' : 'text-slate-900') : 'text-slate-500 italic'}`}>{user.full_name || 'Google User'}</span>
                                {!user.user_password ? (<span className={`px-1.5 py-0.5 rounded-[4px] text-[8px] font-bold uppercase tracking-wide flex items-center gap-0.5 border ${theme === 'dark' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 'bg-rose-100 text-rose-600 border-rose-200'}`}>Google</span>) : (<span className={`px-1.5 py-0.5 rounded-[4px] text-[8px] font-bold uppercase tracking-wide flex items-center gap-0.5 border ${theme === 'dark' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-indigo-100 text-indigo-600 border-indigo-200'}`}><span>🔑</span> Manual</span>)}
                              </div>
                              <span className={`text-[10px] font-medium ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>{user.email}</span>
                            </div>
                          </td>
                          <td className="p-3"><span className={`px-2.5 py-1 rounded-full text-[9px] font-bold uppercase tracking-wide flex items-center w-fit gap-1 border ${statusColor}`}>{user.is_active && !isExpired ? <span>✅</span> : <span>❌</span>} {user.is_active && !isExpired ? 'Active' : 'Locked'}</span></td>
                          <td className="p-3">{formatExpiryUI(user.expires_at)}</td>
                          <td className={`p-3 text-[10px] font-mono ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>{user.device_id ? <span className={`px-2 py-1 rounded border ${theme === 'dark' ? 'bg-slate-950 border-slate-700' : 'bg-slate-200 border-slate-300'}`}>{user.device_id}</span> : <span className="italic">No device</span>}</td>
                          <td className="p-3 flex items-center justify-end gap-1.5">
                            {!user.is_active || isExpired ? (
                              <button onClick={() => openSubscriptionModal('single', user.id)} className={`btn-smooth px-2.5 py-1.5 text-[10px] font-bold rounded flex items-center gap-1 border ${theme === 'dark' ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/30' : 'bg-emerald-100 text-emerald-700 border-emerald-300'}`} title="Approve"><span>✅</span> Approv</button>
                            ) : (
                              <>
                                <button onClick={() => openSubscriptionModal('single', user.id)} className={`btn-smooth px-2.5 py-1.5 text-[10px] font-bold rounded flex items-center gap-1 border ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30' : 'bg-blue-100 text-blue-600 border-blue-300'}`} title="Renew"><span>📅</span> Renew</button>
                                <button onClick={() => handleUserAction(user.id, 'revoke')} className={`btn-smooth px-2.5 py-1.5 text-[10px] font-bold rounded flex items-center gap-1 border ${theme === 'dark' ? 'bg-amber-600/20 text-amber-400 border-amber-500/30' : 'bg-amber-100 text-amber-700 border-amber-300'}`} title="Revoke"><span>🚫</span></button>
                              </>
                            )}
                            <button onClick={() => handleUserAction(user.id, 'reset')} disabled={!user.device_id} className={`btn-smooth px-2.5 py-1.5 text-[10px] font-bold rounded flex items-center gap-1 border ${user.device_id ? (theme === 'dark' ? 'bg-slate-700 text-white border-slate-600 hover:bg-slate-600' : 'bg-slate-200 text-slate-900 border-slate-400 hover:bg-slate-300') : (theme === 'dark' ? 'bg-slate-800/50 text-slate-600 border-slate-700 cursor-not-allowed' : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed')}`} title="Reset Device"><span>💻</span></button>
                            <button onClick={() => handleDeleteUser(user.id)} className={`btn-smooth px-2.5 py-1.5 text-[10px] font-bold rounded flex items-center gap-1 border ${theme === 'dark' ? 'bg-rose-600/20 text-rose-400 border-rose-500/30' : 'bg-rose-100 text-rose-700 border-rose-300'}`} title="Delete User"><span>🗑️</span></button>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ADMIN TAB: SETTINGS & ROUTING */}
        {adminTab === 'settings' && (
          <div className={`p-4 md:p-8 rounded-2xl md:rounded-3xl shadow-xl dark:shadow-2xl border animate-fade-in-up ${theme === 'dark' ? 'bg-slate-800/50 text-slate-300 border-slate-700' : 'bg-white text-slate-900 border-slate-200'}`}>
            <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 border-b pb-4 gap-4 ${theme === 'dark' ? 'border-slate-700' : 'border-slate-200'}`}>
              <div>
                 <h3 className={`text-lg md:text-2xl font-bold flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>🤖</span> AI Model Routing</h3>
                 <p className={`text-xs md:text-sm mt-1 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>Configure global app routing and upcoming platforms.</p>
              </div>
            </div>

            <div className="space-y-6">
              
              {/* AI MODEL ROUTING TABLE */}
              <div className={`p-5 rounded-xl border hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                <div className={`flex justify-between items-center mb-4 border-b pb-3 ${theme === 'dark' ? 'border-slate-800' : 'border-slate-300'}`}>
                  <h4 className={`text-sm font-bold flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                    <span>⚡</span> Active Models (Priority Based)
                  </h4>
                  <button onClick={handleAddAiModel} className={`btn-smooth px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 border ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30 hover:bg-[#00d4ff]/20' : 'bg-blue-100 text-blue-600 border-blue-300 hover:bg-blue-200'}`}>
                    <span>➕</span> Add Provider
                  </button>
                </div>
                
                <div className={`overflow-x-auto rounded-lg border custom-scrollbar ${theme === 'dark' ? 'border-slate-800' : 'border-slate-300'}`}>
                  <table className="w-full text-left border-collapse min-w-[700px]">
                    <thead>
                      <tr className={`text-[10px] uppercase tracking-wider border-b ${theme === 'dark' ? 'bg-slate-950 text-slate-400 border-slate-800' : 'bg-slate-200 text-slate-600 border-slate-300'}`}>
                        <th className="p-3 w-12 text-center">Pri.</th>
                        <th className="p-3 font-semibold">Provider / ID</th>
                        <th className="p-3 font-semibold">Model Name</th>
                        <th className="p-3 font-semibold">Endpoint URL</th>
                        <th className="p-3 font-semibold text-center w-20">Active</th>
                        <th className="p-3 font-semibold text-center w-12">🗑️</th>
                      </tr>
                    </thead>
                    <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-800 bg-slate-900' : 'divide-slate-200 bg-white'}`}>
                      {safeModels.length === 0 ? (
                        <tr><td colSpan={6} className="p-4 text-center text-[10px] italic text-slate-500">No AI Models configured. Add one above.</td></tr>
                      ) : (
                        safeModels.map((model) => {
                          if (!model) return null;
                          return (
                          <tr key={model.id} className={`transition-colors ${theme === 'dark' ? 'hover:bg-slate-800/50' : 'hover:bg-slate-50'}`}>
                            <td className="p-2">
                              <input type="number" min="1" value={model.priority || 0} onChange={(e) => handleUpdateAiModel(model.id, 'priority', parseInt(e.target.value))} className={`w-full border text-center p-1.5 rounded text-xs ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'}`} />
                            </td>
                            <td className="p-2 space-y-1">
                              <input type="text" value={model.provider_name || ''} onChange={(e) => handleUpdateAiModel(model.id, 'provider_name', e.target.value)} placeholder="Name (e.g. Groq)" className={`w-full border p-1.5 rounded text-xs font-bold ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'}`} />
                              <input type="text" value={model.provider_id || ''} onChange={(e) => handleUpdateAiModel(model.id, 'provider_id', e.target.value.toLowerCase())} placeholder="ID (e.g. groq)" className={`w-full border p-1.5 rounded text-[10px] font-mono lowercase ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-slate-500' : 'bg-slate-100 border-slate-300 text-slate-500'}`} />
                            </td>
                            <td className="p-2">
                              <input type="text" value={model.model_name || ''} onChange={(e) => handleUpdateAiModel(model.id, 'model_name', e.target.value)} placeholder="e.g. llama3-70b-8192" className={`w-full border p-1.5 rounded text-xs ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'}`} />
                            </td>
                            <td className="p-2">
                              <input type="text" value={model.api_url || ''} onChange={(e) => handleUpdateAiModel(model.id, 'api_url', e.target.value)} placeholder="https://api..." className={`w-full border p-1.5 rounded text-[10px] font-mono ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-slate-400' : 'bg-slate-100 border-slate-300 text-slate-600'}`} />
                            </td>
                            <td className="p-2 text-center">
                               <div onClick={() => handleUpdateAiModel(model.id, 'is_active', !model.is_active)} className={`mx-auto w-10 h-5 flex items-center rounded-full cursor-pointer transition-colors p-0.5 ${model.is_active ? 'bg-emerald-500' : (theme === 'dark' ? 'bg-slate-700' : 'bg-slate-300')}`}>
                                 <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ${model.is_active ? 'translate-x-5' : 'translate-x-0'}`}></div>
                               </div>
                            </td>
                            <td className="p-2 text-center">
                               <button onClick={() => handleRemoveAiModel(model.id)} className={`text-rose-500 hover:text-rose-700 p-1 rounded transition-colors ${theme === 'dark' ? 'hover:bg-rose-500/20' : 'hover:bg-rose-100'}`}><span>🗑️</span></button>
                            </td>
                          </tr>
                        )})
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className={`p-5 rounded-xl border space-y-4 hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                 <div><label className={`flex items-center gap-2 text-sm font-bold mb-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>⚠️</span> Extension Update Notice</label><textarea value={appSettings?.update_notice || ''} onChange={(e) => setAppSettings({...appSettings, update_notice: e.target.value})} placeholder="Enter notice message here..." className={`input-smooth w-full p-3 rounded-lg text-sm resize-none h-24 border ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white placeholder:text-slate-600' : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'}`}/></div>
                 <div>
                   <label className={`flex items-center gap-2 text-sm font-bold mb-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}><span>🔗</span> Notice Action Link (Optional)</label>
                   <input type="text" value={appSettings?.notice_link || ''} onChange={(e) => setAppSettings({...appSettings, notice_link: e.target.value})} placeholder="https://..." className={`input-smooth w-full p-3 rounded-lg text-sm border ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white placeholder:text-slate-600' : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'}`}/>
                   <p className={`text-[10px] mt-2 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>If left empty, the notification banner will just show the text without a download/action button.</p>
                 </div>
              </div>

              {/* DYNAMIC PLATFORMS */}
              <div className={`p-5 rounded-xl border hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                <h4 className={`flex items-center justify-between text-sm font-bold mb-4 border-b pb-3 ${theme === 'dark' ? 'text-white border-slate-800' : 'text-slate-900 border-slate-300'}`}>
                  <div className="flex items-center gap-2"><span>📑</span> Manage Coming Soon Platforms</div>
                </h4>
                <div className="space-y-4">
                  {safePlatforms.length === 0 ? (
                     <p className="text-xs italic text-center py-4 text-slate-500">No upcoming platforms added yet.</p>
                  ) : (
                    safePlatforms.map((platform) => {
                      if (!platform) return null;
                      return (
                      <div key={platform.id} className={`p-4 rounded-lg border flex flex-col md:flex-row gap-3 items-end transition-all duration-300 ${platform.is_hidden ? 'opacity-50 grayscale' : ''} ${theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'}`}>
                        <div className="flex-1 w-full">
                           <label className={`text-[10px] mb-1 block ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Platform Name</label>
                           <input type="text" value={platform.name || ''} onChange={(e) => handleUpdatePlatform(platform.id, 'name', e.target.value)} placeholder="e.g. Freepik" className={`input-smooth w-full p-2.5 rounded-lg text-xs border ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white placeholder:text-slate-600' : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'}`}/>
                        </div>
                        <div className="flex-1 w-full">
                           <label className={`text-[10px] mb-1 block ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Icon URL</label>
                           <div className="flex gap-2">
                             <input type="text" value={platform.icon_url || ''} onChange={(e) => handleUpdatePlatform(platform.id, 'icon_url', e.target.value)} placeholder="https://..." className={`input-smooth flex-1 p-2.5 rounded-lg text-xs border ${theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white placeholder:text-slate-600' : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'}`}/>
                             <label className={`btn-smooth px-3 rounded-lg cursor-pointer flex items-center justify-center border ${theme === 'dark' ? 'bg-slate-800 text-[#00d4ff] border-slate-700 hover:bg-slate-700' : 'bg-blue-100 text-blue-600 border-blue-300 hover:bg-blue-200'}`}><span>☁️</span><input type="file" className="hidden" accept="image/*" onChange={(e) => handlePlatformIconUpload(e, platform.id)} /></label>
                           </div>
                        </div>
                        <div className="flex items-end pb-0.5 w-full md:w-auto gap-2">
                           <button onClick={() => handleTogglePlatformVisibility(platform.id)} className={`btn-smooth w-full md:w-auto justify-center p-2.5 rounded-lg border hover:bg-opacity-20 ${platform.is_hidden ? (theme === 'dark' ? 'bg-slate-700/50 text-slate-400 border-slate-600' : 'bg-slate-200 text-slate-600 border-slate-300') : (theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30 hover:bg-[#00d4ff]/20' : 'bg-blue-100 text-blue-600 border-blue-300 hover:bg-blue-200')}`} title={platform.is_hidden ? "Show in Extension" : "Hide from Extension"}>
                             {platform.is_hidden ? <span>🙈</span> : <span>👁️</span>}
                           </button>
                           <button onClick={() => handleRemovePlatform(platform.id)} className={`btn-smooth w-full md:w-auto justify-center p-2.5 rounded-lg border ${theme === 'dark' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 hover:bg-rose-500/20' : 'bg-rose-100 text-rose-600 border-rose-300 hover:bg-rose-200'}`}>
                             <span>🗑️</span>
                           </button>
                        </div>
                      </div>
                    )})
                  )}
                  <button onClick={handleAddPlatform} className={`btn-smooth w-full py-2.5 border border-dashed rounded-lg flex items-center justify-center gap-2 text-xs font-bold transition-colors ${theme === 'dark' ? 'border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-white' : 'border-slate-300 text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`}><span>➕</span> Add New Platform</button>
                </div>
              </div>

              <div className={`p-5 rounded-xl border flex items-center justify-between hover-card ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                 <div>
                   <label className={`flex items-center gap-2 text-sm font-bold mb-1 ${theme === 'dark' ? 'text-rose-400' : 'text-rose-600'}`}><span>🛑</span> Maintenance Mode (Kill Switch)</label>
                   <p className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>If enabled, the extension will be locked for all users.</p>
                 </div>
                 <div onClick={() => setAppSettings({...appSettings, is_maintenance: !appSettings.is_maintenance})} className={`w-14 h-7 flex items-center rounded-full cursor-pointer transition-colors p-1 ${appSettings.is_maintenance ? 'bg-rose-600' : (theme === 'dark' ? 'bg-slate-700' : 'bg-slate-300')}`}>
                   <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-300 ${appSettings.is_maintenance ? 'translate-x-7' : 'translate-x-0'}`}></div>
                 </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button onClick={handleSaveAppSettings} disabled={isSavingSettings} className={`btn-smooth font-bold px-6 py-3 rounded-xl shadow-lg flex items-center gap-2 text-sm ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[#00d4ff]/20 hover:bg-[#00b8ff]' : 'bg-blue-600 text-white shadow-blue-500/20 hover:bg-blue-700'}`}>
                  {isSavingSettings ? <span className="animate-spin inline-block">🔄</span> : <span>✅</span>} {isSavingSettings ? 'Saving...' : 'Deploy Configuration'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SUBSCRIPTION MODAL */}
      {isSubModalOpen && (
        <div className="fixed inset-0 z-[99999] bg-black/60 backdrop-blur-sm flex items-center justify-center animate-fade-in-up px-4">
          <div className={`border p-6 md:p-8 rounded-3xl shadow-2xl w-full max-w-md ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
            <h3 className={`text-xl font-bold mb-2 text-center ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Select Subscription Plan</h3>
            <p className={`text-xs text-center mb-6 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>Choose a duration to generate the precise expiry date.</p>
            <div className="grid grid-cols-2 gap-3 mb-8">
               {[{label: '1 Month', val: 1}, {label: '3 Months', val: 3}, {label: '6 Months', val: 6}, {label: '1 Year', val: 12}, {label: 'Lifetime', val: null}].map(plan => (
                 <button key={plan.label} onClick={() => setSelectedDuration(plan.val)} className={`btn-smooth py-3 px-4 rounded-xl border text-sm font-bold transition-all flex flex-col items-center justify-center gap-1 ${selectedDuration === plan.val ? (theme === 'dark' ? 'bg-[#00d4ff]/10 border-[#00d4ff] text-[#00d4ff] shadow-[0_0_15px_rgba(0,212,255,0.2)]' : 'bg-blue-100 border-blue-600 text-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.2)]') : (theme === 'dark' ? 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100')}`}>
                   {plan.val === null ? <span>♾️</span> : <span>📅</span>} {plan.label}
                 </button>
               ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setIsSubModalOpen(false)} className={`btn-smooth flex-1 py-3 rounded-xl text-sm font-bold border ${theme === 'dark' ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'}`}>Cancel</button>
              <button onClick={confirmSubscriptionAction} className={`btn-smooth flex-1 py-3 rounded-xl text-sm font-extrabold shadow-lg ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[#00d4ff]/20 hover:bg-[#00b8ff]' : 'bg-blue-600 text-white shadow-blue-500/20 hover:bg-blue-700'}`}>Confirm &amp; Activate</button>
            </div>
          </div>
        </div>
      )}

      {/* Sticky Save Bar */}
      {adminTab === 'content' && (
        <div className={`fixed bottom-0 left-0 w-full p-3 sm:p-4 md:p-6 flex justify-center z-50 transition-transform duration-500 ease-[cubic-bezier(0.25,0.1,0.25,1)] ${hasUnsavedChanges || saveSuccess ? 'translate-y-0' : 'translate-y-32'}`}>
          <div className={`backdrop-blur-2xl border px-4 md:px-6 py-3 md:py-4 rounded-2xl flex items-center gap-4 w-full max-w-2xl justify-between ${theme === 'dark' ? 'bg-slate-900/90 border-slate-700 shadow-[0_-5px_30px_rgba(0,0,0,0.3)]' : 'bg-white/90 border-slate-200 shadow-[0_-5px_30px_rgba(0,0,0,0.1)]'}`} style={{transform: 'translateZ(0)'}}>
            <div className={`text-xs md:text-sm font-medium ${theme === 'dark' ? 'text-slate-300' : 'text-slate-800'}`}>{saveSuccess ? <span className={`flex items-center gap-1.5 ${theme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}><span>✅</span> Saved</span> : "Unsaved changes"}</div>
            <button onClick={handleSave} disabled={isSaving || saveSuccess} className={`btn-smooth px-5 py-2.5 rounded-xl font-extrabold text-xs shadow-md ${saveSuccess ? 'bg-emerald-500 text-white' : (theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221]' : 'bg-blue-600 text-white')}`}>{isSaving ? 'Saving...' : saveSuccess ? 'Saved!' : 'Save Now'}</button>
          </div>
        </div>
      )}
    </div>
  );

  const renderLoginPage = () => (
    <div className={`min-h-screen flex items-center justify-center p-4 font-sans relative z-10 hardware-accelerated transition-colors duration-500 ${theme === 'dark' ? 'bg-[#020617]' : 'bg-slate-50'}`}>
      <div className="absolute top-4 right-4 z-50">
        <button onClick={toggleTheme} className={`p-2 rounded-full shadow-md border transition-colors ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100'}`}>
          {theme === 'light' ? <span>🌙</span> : <span>☀️</span>}
        </button>
      </div>

      <form onSubmit={handleLogin} className={`w-full max-w-sm backdrop-blur-xl border p-6 md:p-8 rounded-3xl shadow-2xl relative z-10 animate-fade-in-up ${theme === 'dark' ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="flex justify-center mb-6"><div className={`p-4 rounded-full shadow-sm border ${theme === 'dark' ? 'bg-[#00d4ff]/10 border-[#00d4ff]/30 text-[#00d4ff]' : 'bg-blue-100 border-blue-200 text-blue-600'}`}><span className="text-[28px]">🔒</span></div></div>
        <h2 className={`text-xl md:text-2xl font-extrabold text-center mb-6 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Admin Login</h2>
        {loginError && <div className={`p-2.5 rounded-lg mb-4 text-center text-xs font-bold border ${theme === 'dark' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 'bg-rose-100 text-rose-600 border-rose-200'}`}>{loginError}</div>}
        <input type="email" placeholder="Email" required value={email} onChange={(e) => setEmail(e.target.value)} className={`input-smooth w-full p-3.5 mb-3 border rounded-xl outline-none text-sm ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white placeholder:text-slate-600' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400'}`} />
        <input type="password" placeholder="Passkey" required value={password} onChange={(e) => setPassword(e.target.value)} className={`input-smooth w-full p-3.5 mb-6 border rounded-xl outline-none text-sm ${theme === 'dark' ? 'bg-slate-950 border-slate-700 text-white placeholder:text-slate-600' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400'}`} />
        <button type="submit" className={`btn-smooth w-full font-extrabold py-3.5 rounded-xl text-sm ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[0_0_15px_rgba(0,212,255,0.3)] hover:bg-[#00b8ff]' : 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] hover:bg-blue-700'}`}>Authenticate</button>
        <button type="button" onClick={() => setCurrentView('home')} className={`w-full mt-4 text-xs font-bold transition-colors ${theme === 'dark' ? 'text-slate-500 hover:text-white' : 'text-slate-500 hover:text-slate-900'}`}>Return to Site</button>
      </form>
    </div>
  );

  const renderDemoPage = () => (
    <div className={`min-h-screen font-sans relative overflow-x-hidden hardware-accelerated z-10 transition-colors duration-500 ${theme === 'dark' ? 'bg-[#020617] text-slate-200' : 'bg-slate-50 text-slate-900'}`}>
      <nav className="relative z-50 p-4 max-w-7xl mx-auto flex justify-between items-center animate-fade-in-up">
         <div className="flex items-center gap-2 cursor-pointer btn-smooth" onClick={() => setCurrentView('home')}>
            {siteData?.logoImage ? <img src={siteData.logoImage} alt="Logo" className={`w-10 h-10 rounded-full shadow-sm border object-cover ${theme === 'dark' ? 'border-slate-700' : 'border-slate-200'}`} /> : <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-sm border ${theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-slate-200 border-slate-300'}`}><span className={`font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>RM</span></div>}
            <h2 className={`text-lg font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Raihan Metadata</h2>
         </div>
         <div className="flex items-center gap-3">
           <button onClick={toggleTheme} className={`p-2.5 rounded-full shadow-md border transition-colors ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100'}`}>
             {theme === 'light' ? <span>🌙</span> : <span>☀️</span>}
           </button>
           <button onClick={() => setCurrentView('home')} className={`btn-smooth backdrop-blur-md border px-5 py-2.5 rounded-full text-sm font-bold flex items-center gap-2 shadow-sm ${theme === 'dark' ? 'bg-slate-800/80 border-slate-700 text-white hover:bg-slate-700' : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100'}`}><span>⬅️</span> Back</button>
         </div>
      </nav>

      <div className="relative z-10 pt-4 pb-12 px-4 max-w-[1600px] mx-auto animate-fade-in-up">
        <div className="text-center mb-8">
          <h2 className={`text-3xl md:text-5xl font-black mb-3 ${theme === 'dark' ? 'text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400' : 'text-slate-900'}`}>Interactive AI Demo</h2>
          <p className={`text-sm md:text-base max-w-2xl mx-auto ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Upload an image and click the extension icon to see the magic happen in real-time.</p>
        </div>

        {/* Browser Mockup */}
        <div className="w-full h-[650px] md:h-[800px] bg-[#f5f5f5] rounded-xl overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.1)] dark:shadow-[0_20px_60px_rgba(0,0,0,0.4)] flex flex-col relative border border-slate-300 dark:border-slate-700" style={{fontFamily: '"adobe-clean", "Helvetica Neue", Helvetica, Arial, sans-serif'}}>
          <div className="bg-[#dee1e6] flex items-end justify-between pr-0 select-none pt-2 overflow-hidden">
            <div className="flex items-center px-2 w-full">
              <div className="bg-white rounded-t-lg px-4 py-2 flex items-center gap-2 text-xs text-gray-700 shadow-[0_1px_0_white] min-w-[150px] md:min-w-[200px] max-w-[250px]">
                <img src={siteData?.mockupLogo || ''} alt="favicon" className="w-3.5 h-3.5 object-contain" decoding="async"/>
                <span className="truncate flex-1 font-medium">Contributors Uploaded Files</span>
                <span className="text-gray-500 hover:bg-gray-200 rounded-full p-0.5 cursor-pointer">❌</span>
              </div>
              <div className="ml-2 w-7 h-7 flex items-center justify-center hover:bg-gray-300 rounded-full cursor-pointer text-gray-500 hidden sm:flex"><span>➕</span></div>
            </div>
            <div className="flex h-full items-start text-gray-600">
              <div className="px-4 py-2 hover:bg-gray-300 cursor-pointer hidden sm:block">−</div>
              <div className="px-4 py-2 hover:bg-gray-300 cursor-pointer hidden sm:block">□</div>
              <div className="px-4 py-2 hover:bg-red-500 hover:text-white cursor-pointer">✕</div>
            </div>
          </div>

          <div className="bg-white px-2 sm:px-4 py-1.5 flex items-center gap-2 sm:gap-4 border-b border-gray-300 select-none shadow-sm z-20 relative">
            <div className="flex items-center gap-1 sm:gap-2 text-gray-500 hidden sm:flex">
              <div className="p-1.5 hover:bg-gray-100 rounded-full cursor-pointer"><span>⬅️</span></div>
              <div className="p-1.5 hover:bg-gray-100 rounded-full cursor-pointer text-gray-300"><span>➡️</span></div>
              <div className="p-1.5 hover:bg-gray-100 rounded-full cursor-pointer"><span>🔄</span></div>
            </div>
            <div className="flex-1 flex items-center bg-[#f1f3f4] px-3 py-1.5 rounded-full text-xs md:text-sm text-gray-700 border border-transparent hover:border-gray-300 focus-within:border-blue-400 focus-within:bg-white input-smooth">
              <span className="mr-2 text-gray-500">🔒</span>
              <span className="flex-1 truncate">contributor.stock.adobe.com/en/uploads</span>
              <span className="text-gray-400 hover:text-gray-600 cursor-pointer hidden sm:block">⭐</span>
            </div>
            <div className="flex items-center gap-1 sm:gap-2 text-gray-600">
              <div className="p-1.5 hover:bg-gray-100 rounded-full cursor-pointer hidden sm:block"><span>🧩</span></div>
              <div onClick={() => setShowExtension(!showExtension)} className="flex items-center justify-center p-1 sm:p-1.5 rounded cursor-pointer hover:bg-gray-100 btn-smooth z-50 animate-pulse">
                {siteData?.extensionIcon ? <img src={siteData.extensionIcon} alt="Ext" className="w-5 h-5 object-contain" decoding="async"/> : <div className="bg-red-600 text-white font-black text-[10px] sm:text-[11px] px-1.5 py-0.5 rounded shadow-sm border border-red-700">MR</div>}
              </div>
              <div className="p-1.5 hover:bg-gray-100 rounded-full cursor-pointer hidden sm:block"><span>📥</span></div>
              <div className="p-1 hover:bg-gray-100 rounded-full cursor-pointer ml-1 hidden sm:block"><div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">R</div></div>
              <div className="p-1.5 hover:bg-gray-100 rounded-full cursor-pointer"><span>⋮</span></div>
            </div>
          </div>

          <div className="bg-[#1e1e1e] text-white flex items-center justify-between px-3 md:px-6 py-2 md:py-3 select-none z-10 relative">
            <div className="flex items-center gap-3 md:gap-6">
              <div className="flex items-center gap-2">
                <img src={siteData?.mockupLogo || ''} alt="Adobe" className="w-4 h-4 md:w-6 md:h-6 object-contain" decoding="async"/>
                <span className="font-bold tracking-wide text-xs md:text-base hidden sm:block">Adobe Stock</span>
              </div>
              <div className="hidden md:flex gap-4 text-xs font-semibold text-gray-300">
                <span className="hover:text-white cursor-pointer">Dashboard</span>
                <span className="text-white border-b-2 border-white pb-1">Uploaded Files</span>
                <span className="hover:text-white cursor-pointer">Insights</span>
              </div>
            </div>
            <div className="flex items-center gap-3 md:gap-5">
              <span className="text-gray-300 hidden sm:block cursor-pointer hover:text-white">🔍</span>
              <span className="text-gray-300 hidden sm:block cursor-pointer hover:text-white">🔔</span>
              <div className="flex items-center gap-1.5 bg-[#323232] border border-gray-600 px-3 py-1 md:py-1.5 rounded-full cursor-pointer hover:bg-gray-700 btn-smooth" onClick={() => setShowUploadModal(true)}>
                <span>☁️</span>
                <span className="text-xs font-bold">Upload</span>
              </div>
              <div className="w-6 h-6 md:w-8 md:h-8 bg-gray-500 rounded-full flex items-center justify-center border border-gray-400 cursor-pointer hover:bg-gray-600">
                <span>👤</span>
              </div>
            </div>
          </div>

          <div className="bg-white border-b border-gray-200 px-3 md:px-6 flex items-center justify-between text-xs md:text-sm text-gray-600 font-semibold overflow-x-auto whitespace-nowrap demo-scroll select-none z-10 relative">
            <div className="flex gap-4 md:gap-6">
               <span className="text-black border-b-[3px] border-black py-2.5 md:py-3 cursor-pointer">New</span>
               <span className="hover:text-black py-2.5 md:py-3 cursor-pointer">In review</span>
               <span className="hover:text-black py-2.5 md:py-3 cursor-pointer hidden sm:block">Reminder</span>
               <span className="hover:text-black py-2.5 md:py-3 cursor-pointer hidden md:block">Not accepted</span>
            </div>
            <div className="py-2">
               <button className="bg-gray-200 text-gray-500 px-4 py-1.5 rounded-full font-bold text-xs cursor-not-allowed hidden sm:block">Submit {safeDemoImages.length || 0} files</button>
            </div>
          </div>

          <div className="flex-1 flex overflow-hidden bg-[#f5f5f5] flex-col md:flex-row">
            <div className="flex-1 p-2 md:p-6 overflow-y-auto demo-scroll relative h-[50%] md:h-auto">
              {(!safeDemoImages || safeDemoImages.length === 0) && !showUploadModal ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-500">
                  <div className="w-16 h-16 md:w-20 md:h-20 bg-gray-200 rounded-full flex items-center justify-center mb-3 md:mb-4">
                    <span className="text-[24px]">🖼️</span>
                  </div>
                  <p className="font-semibold text-gray-600 mb-1 text-sm md:text-base">No items</p>
                  <p className="text-[10px] md:text-xs">To upload files, click Upload in the header</p>
                  <button onClick={() => setShowUploadModal(true)} className="mt-4 px-5 py-2 bg-blue-600 text-white rounded-full font-bold text-xs md:text-sm hover:bg-blue-700 btn-smooth sm:hidden shadow-sm">
                    Upload Image
                  </button>
                </div>
              ) : (
                <div className="flex flex-wrap justify-center md:justify-start">
                  {safeDemoImages.map((img, i) => {
                    if (!img) return null;
                    const isActive = selectedDemoImage === i;
                    return (
                      <div key={i} className="inline-block m-1 md:mr-4 md:mb-4" onClick={() => setSelectedDemoImage(i)}>
                        <div className="relative bg-white shadow-sm border border-gray-200 hover-card cursor-pointer">
                          <div className={`relative box-border transition-all duration-100 ${isActive ? 'border-[3px] border-blue-600' : 'border-[3px] border-transparent'}`} style={{ width: '100%', maxWidth: '330px', height: '180px' }}>
                            <img className="w-full h-full object-cover" src={img.url || ''} alt="thumbnail" decoding="async" loading="lazy" />
                            {isActive && <div className="absolute top-2 left-2 w-5 h-5 bg-blue-600 rounded-full border-2 border-white flex items-center justify-center shadow-md"><span>✔️</span></div>}
                          </div>
                          <div className="bg-[#f5f5f5] w-full max-w-[330px] flex items-center justify-between px-3 py-1.5 text-[11px] text-[#767676] border-t border-gray-200">
                            <div className="flex items-center gap-3"><span className="flex items-center gap-1"><span>🏷️</span> 0</span><span className="flex items-center gap-1"><span>👥</span> 0</span></div>
                            <div><div className="w-2.5 h-2.5 rounded-full bg-[#ff4b4b]"></div></div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}

              {showUploadModal && (
                <div className="absolute inset-0 bg-white/95 z-20 flex flex-col md:flex-row animate-fade-in-up">
                  <div className="flex-1 flex flex-col items-center justify-center p-6 border-r border-gray-200 relative">
                    <button onClick={() => setShowUploadModal(false)} className="absolute top-3 right-3 text-gray-500 hover:text-black md:hidden"><span>❌</span></button>
                    <h2 className="text-lg md:text-2xl font-bold mb-6 md:mb-10 text-[#1e1e1e] text-center">Upload your files to start selling</h2>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" multiple onChange={handleDemoFileUpload} />
                    <div onClick={() => fileInputRef.current?.click()} className={`w-40 h-40 md:w-64 md:h-64 bg-blue-600 rounded-full text-white flex flex-col items-center justify-center cursor-pointer btn-smooth shadow-[0_10px_30px_rgba(37,99,235,0.3)] ${isProcessingImages ? 'animate-pulse scale-95' : 'hover:bg-blue-700 hover:scale-105'}`}>
                      {isProcessingImages ? <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div> : <><span className="text-[36px] mb-2 md:mb-4">📤</span><span className="font-bold text-sm md:text-lg text-center px-4">Drag &amp; Drop files or <br/><span className="underline">Browse</span></span></>}
                    </div>
                    <p className="mt-6 md:mt-10 text-[10px] md:text-xs text-gray-500 font-semibold text-center">{isProcessingImages ? "Compressing images to save memory..." : "Max 10 files for this demo to save memory."}</p>
                  </div>
                  <div className="w-full md:w-64 bg-gray-50 p-4 md:p-6 hidden sm:block relative">
                    <button onClick={() => setShowUploadModal(false)} className="absolute top-4 right-4 text-gray-500 hover:text-black"><span>❌</span></button>
                    <div className="mt-10 space-y-4">
                      <div className="flex items-center justify-between text-xs font-bold text-gray-700 cursor-pointer border-b border-gray-200 pb-2 hover:text-blue-600"><span>TRANSPARENT PNG</span> <span>▶</span></div>
                      <div className="flex items-center justify-between text-xs font-bold text-gray-700 cursor-pointer border-b border-gray-200 pb-2 hover:text-blue-600"><span>IMAGES (JPEG FILES)</span> <span>▼</span></div>
                      <div className="flex items-center justify-between text-xs font-bold text-gray-700 cursor-pointer border-b border-gray-200 pb-2 hover:text-blue-600"><span>VECTORS (AI, EPS, SVG)</span> <span>▶</span></div>
                      <div className="flex items-center justify-between text-xs font-bold text-gray-700 cursor-pointer border-b border-gray-200 pb-2 hover:text-blue-600"><span>VIDEOS</span> <span>▶</span></div>
                      <p className="text-[10px] text-blue-600 font-bold mt-4 cursor-pointer hover:underline">Contributor submission guide</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {safeDemoImages.length > 0 && selectedDemoImage !== null && (
              <div className="w-full md:w-[350px] bg-white border-t md:border-t-0 md:border-l border-gray-200 flex flex-col overflow-y-auto demo-scroll animate-fade-in-up relative z-10 shadow-[0_-5px_15px_rgba(0,0,0,0.05)] md:shadow-[-5px_0_15px_rgba(0,0,0,0.05)] h-[50%] md:h-auto">
                <div className="px-4 py-3 md:px-6 md:py-4 bg-[#fafafa] border-b border-gray-200 flex gap-3">
                  <div className="w-20 h-12 md:w-28 md:h-16 overflow-hidden"><img src={safeDemoImages[selectedDemoImage]?.url || ''} alt="thumb" className="w-full h-full object-cover rounded shadow-sm border border-gray-300" decoding="async" loading="lazy" /></div>
                  <div className="flex-1 flex flex-col justify-end pb-1">
                    <label className="flex items-center gap-1.5 text-[10px] md:text-xs text-gray-600 cursor-not-allowed opacity-50"><input type="checkbox" className="accent-blue-600 w-3 h-3 md:w-4 md:h-4" disabled /><span>Include in submission</span></label>
                    <div className="flex justify-end mt-1"><span className="text-gray-400 cursor-pointer hover:text-gray-600">🗑️</span></div>
                  </div>
                </div>

                <div className="px-4 py-3 md:px-6 md:pt-3 md:pb-8 space-y-3 md:space-y-4">
                  <div className="flex gap-2">
                    <div className="flex-1"><label className="block text-[10px] md:text-[11px] text-gray-600 mb-1">File type</label><div className="relative"><select className="w-full text-[10px] md:text-xs p-1.5 md:p-2.5 border border-gray-300 rounded focus:outline-none focus:border-blue-500 bg-white appearance-none cursor-pointer input-smooth"><option>Photos</option><option>Illustrations</option></select><span className="absolute right-2 top-2.5 text-gray-500 pointer-events-none">▼</span></div></div>
                    <div className="flex-1"><label className="block text-[10px] md:text-[11px] text-gray-600 mb-1">Category</label><div className="relative"><select className="w-full text-[10px] md:text-xs p-1.5 md:p-2.5 border border-gray-300 rounded focus:outline-none focus:border-blue-500 bg-white appearance-none cursor-pointer input-smooth"><option>Hobbies and Leisure</option><option>Technology</option></select><span className="absolute right-2 top-2.5 text-gray-500 pointer-events-none">▼</span></div></div>
                  </div>
                  <div><label className="block text-[10px] md:text-[11px] text-gray-600 mb-1">I&apos;m writing title &amp; keywords in</label><div className="relative"><select className="w-full text-[10px] md:text-xs p-1.5 md:p-2.5 border border-gray-300 rounded focus:outline-none focus:border-blue-500 bg-white appearance-none cursor-pointer input-smooth"><option>English</option><option>Français</option></select><span className="absolute right-2 top-2.5 md:top-3 text-gray-500 pointer-events-none">▼</span></div></div>

                  <div className="space-y-1.5 pt-1">
                    <label className="flex items-start gap-2 cursor-not-allowed opacity-50"><input type="checkbox" className="mt-0.5 w-3.5 h-3.5" disabled /><span className="text-[10px] md:text-xs text-gray-700 leading-tight">This is Illustrative Editorial content</span></label>
                    <label className="flex items-start gap-2 cursor-pointer"><input type="checkbox" className="mt-0.5 w-3.5 h-3.5 accent-blue-600" /><span className="text-[10px] md:text-xs text-gray-700 leading-tight font-medium">Created using generative AI tools</span></label>
                  </div>

                  <div className="pt-2">
                    <label className="block text-[10px] md:text-[11px] text-[#767676] mb-2 uppercase font-medium">Recognizable people or property?</label>
                    <div className="flex gap-2"><button className="btn-smooth flex-1 py-1 md:py-1.5 bg-white border border-gray-300 rounded-full text-[10px] md:text-xs font-bold text-gray-700 shadow-sm">Yes</button><button className="btn-smooth flex-1 py-1 md:py-1.5 bg-gray-100 border border-transparent rounded-full text-[10px] md:text-xs font-bold text-gray-500">No</button></div>
                  </div>

                  <div className="pt-2">
                    <div className="relative">
                      <textarea value={demoTitle} readOnly placeholder="Type title here (max: 200 characters)" className={`input-smooth w-full text-xs md:text-sm p-2 md:p-3 border rounded focus:outline-none resize-none h-[60px] md:h-[75px] ${!isMetadataFilled ? 'border-[#d31510] bg-white' : 'border-green-500 bg-green-50/20 text-gray-800 font-medium'}`}/>
                      {!isMetadataFilled && <span className="absolute right-3 top-3 text-[#d31510]">⚠️</span>}
                    </div>
                    {!isMetadataFilled && <div className="text-[10px] md:text-[11px] text-[#d31510] mt-1">Missing or invalid title.</div>}
                  </div>

                  <div>
                    <div className="flex justify-between items-end mb-1">
                      <label className="block text-[10px] md:text-[11px] text-[#767676] uppercase font-medium">Keywords <span className="lowercase font-normal text-gray-400">(min: 5 - max: 49)</span></label>
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <span className="text-[9px] md:text-[10px] text-gray-700">Reordering tool</span>
                        <div className="w-5 md:w-6 h-3 md:h-3.5 bg-gray-300 rounded-full relative"><div className="w-2 h-2 md:w-2.5 md:h-2.5 bg-white rounded-full absolute left-0.5 top-0.5"></div></div>
                      </label>
                    </div>
                    <div className="relative">
                      <textarea value={demoTags} readOnly placeholder="Paste Keywords..." className={`input-smooth w-full text-xs md:text-sm p-2 md:p-3 border rounded focus:outline-none resize-none h-[80px] md:h-[110px] ${!isMetadataFilled ? 'border-[#d31510] bg-white' : 'border-green-500 bg-green-50/20 text-gray-800 font-medium'}`}/>
                      {!isMetadataFilled && <span className="absolute right-3 top-3 text-[#d31510]">⚠️</span>}
                    </div>
                    {!isMetadataFilled && <div className="text-[10px] md:text-[11px] text-[#d31510] mt-1 mb-1">Add minimum 5 keywords.</div>}
                    <div className="text-[9px] md:text-[11px] text-right text-gray-500 mt-1">Remaining keywords: {demoTags ? '29' : '49'}</div>
                  </div>

                  {!isMetadataFilled && (
                    <div className="pt-1 md:pt-2">
                      <label className="block text-[11px] md:text-[12px] text-gray-800 font-bold mb-2">Keyword suggestions:</label>
                      <div className="flex flex-wrap gap-1 md:gap-1.5">
                        {['beach', 'sunset', 'sun', 'silhouette', 'sea', 'illustration', 'sky', 'summer', 'people', 'vector', 'palm'].map(tag => (
                          <div key={tag} className="btn-smooth text-[9px] md:text-[11px] px-2 md:px-3 py-1 md:py-1.5 bg-white border border-gray-300 rounded-full flex items-center gap-1 md:gap-1.5 cursor-pointer text-gray-700 font-medium shadow-sm">
                            {tag} <span>➕</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="pt-3 mt-3 md:pt-4 md:mt-4 border-t border-gray-200 hidden md:block">
                    <div className="text-[10px] md:text-[11px] text-gray-500 mb-2">File ID(s): {1943095978 + selectedDemoImage} <br/> Original name(s): image.png</div>
                    <div className="font-bold text-[12px] md:text-[13px] text-gray-800 mb-2">Actions:</div>
                    <div className="space-y-2">
                      <button className="flex items-center gap-2 text-[12px] md:text-[13px] text-gray-700 hover:text-black"><span>🗑️</span> Erase all keywords</button>
                      <button className="flex items-center gap-2 text-[12px] md:text-[13px] text-gray-700 hover:text-black"><span className="inline-block">🔄</span> Refresh auto-category</button>
                    </div>
                  </div>
                </div>

                <div className="mt-auto p-3 md:p-4 border-t border-gray-200 bg-white sticky bottom-0">
                  <button className="w-full py-2 md:py-2.5 bg-gray-200 text-gray-500 text-xs md:text-sm font-bold rounded-full cursor-not-allowed">Save work</button>
                </div>
              </div>
            )}
          </div>

          {showExtension && (
            <div className="absolute top-[45px] sm:top-[50px] right-2 sm:right-16 md:right-[350px] w-[260px] sm:w-[300px] md:w-[320px] bg-[#0B1221] border border-slate-700 shadow-[0_20px_60px_rgba(0,0,0,0.8)] rounded-xl z-50 flex flex-col animate-fade-in-up overflow-hidden text-white" style={{transform: 'translateZ(0)'}}>
              <div className="absolute top-[-50px] left-[-50px] w-[150px] h-[150px] bg-blue-600/30 rounded-full blur-[50px] pointer-events-none"></div>
              <div className="absolute bottom-[-50px] right-[-50px] w-[150px] h-[150px] bg-purple-600/20 rounded-full blur-[50px] pointer-events-none"></div>

              <div className="relative z-10 flex justify-between items-center p-4 border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-md">
                <div>
                  <span className="text-[9px] font-bold text-blue-400 tracking-widest uppercase block mb-0.5">RAIHAN</span>
                  <h1 className="text-sm font-black m-0 leading-none">Metadata Pro</h1>
                </div>
                <button onClick={() => setShowExtension(false)} className="text-slate-400 hover:text-white bg-slate-800 p-1.5 rounded-full"><span>❌</span></button>
              </div>

              <div className="relative z-10 p-4">
                 <div className="text-[10px] font-bold text-slate-500 tracking-wider mb-2">ACTIVE PLATFORMS</div>
                 <div className="grid grid-cols-2 gap-3 mb-5">
                    <div className="bg-blue-600/20 border border-blue-500/50 rounded-lg p-2.5 flex flex-col items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(37,99,235,0.2)]">
                      <img src={siteData?.mockupLogo || 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Adobe_Stock_icon.svg/512px-Adobe_Stock_icon.svg.png'} className="w-6 h-6 object-contain" alt="adobe" />
                      <span className="text-xs font-bold text-white">Adobe</span>
                    </div>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-2.5 flex flex-col items-center justify-center gap-2 cursor-pointer opacity-50">
                      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Shutterstock_logo.svg/512px-Shutterstock_logo.svg.png" className="w-6 h-6 object-contain grayscale" alt="shutterstock" />
                      <span className="text-xs font-bold text-slate-400">Shutterstock</span>
                    </div>
                 </div>

                 <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-3 mb-5 flex justify-between items-center">
                    <div>
                      <h4 className="text-xs font-bold text-white mb-0.5">Adobe Auto</h4>
                      <p className="text-[10px] text-slate-400">Automatic Generation</p>
                    </div>
                    <div className="w-10 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors bg-emerald-500">
                       <div className="bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 translate-x-4"></div>
                    </div>
                 </div>

                 <button onClick={handleGenerateDemoMetadata} disabled={isGeneratingDemo} className="w-full font-bold py-3 rounded-xl flex items-center justify-center gap-2 text-xs transition-all bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] hover:bg-blue-500">
                    {isGeneratingDemo ? <span className="animate-spin inline-block">🔄</span> : <span>⚡</span>} 
                    {isGeneratingDemo ? "Processing Image..." : "Generate Magic Now"}
                 </button>
              </div>

              <div className="relative z-10 bg-slate-950/80 p-3 flex justify-between items-center border-t border-slate-800">
                 <div className="flex items-center gap-2 text-slate-400">
                    <div className="bg-slate-800 p-1 rounded-full"><span>👤</span></div>
                    <span className="text-[10px] font-medium">user@email.com</span>
                 </div>
                 <button className="text-[10px] text-rose-400 font-bold hover:text-rose-300">Reset Key</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderLandingPage = () => (
    <div className={`min-h-screen font-sans selection:bg-blue-600/30 dark:selection:bg-[#00d4ff]/30 relative overflow-x-hidden opacity-100 hardware-accelerated bg-grid-pattern-light dark:bg-grid-pattern-dark z-10 transition-colors duration-500 ${theme === 'dark' ? 'bg-[#020617] text-slate-200' : 'bg-slate-50 text-slate-900'}`}>
      
      <div className="fixed inset-0 z-0 pointer-events-none" style={{transform: 'translate3d(0,0,0)', willChange: 'transform'}}>
        <div className={`absolute top-[5%] left-[-5%] w-[300px] h-[300px] md:w-[600px] md:h-[600px] rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-[100px] md:blur-[150px] opacity-15 ${theme === 'dark' ? 'bg-[#00d4ff]' : 'bg-blue-600'}`}></div>
      </div>

      <nav className={`sticky top-0 z-50 backdrop-blur-2xl border-b transition-all duration-300 ${theme === 'dark' ? 'bg-[#0f172a]/80 border-slate-800' : 'bg-white/80 border-slate-200'}`} style={{transform: 'translateZ(0)'}}>
        <div className="max-w-7xl mx-auto px-4 flex justify-between h-16 md:h-20 items-center overflow-hidden">
          <div className="flex items-center gap-2 md:gap-3 cursor-pointer group select-none btn-smooth" onDoubleClick={handleAdminAccess}>
            {siteData?.logoImage ? <img src={siteData.logoImage} alt="Logo" className={`w-8 h-8 sm:w-9 sm:h-9 md:w-11 md:h-11 rounded-full border object-cover ${theme === 'dark' ? 'shadow-[0_0_15px_rgba(0,212,255,0.4)] border-slate-700' : 'shadow-[0_0_15px_rgba(37,99,235,0.2)] border-slate-200'}`} decoding="async" loading="lazy" /> : <div className={`w-8 h-8 sm:w-9 sm:h-9 md:w-11 md:h-11 rounded-full flex items-center justify-center shadow-sm border ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-[#00d4ff]' : 'bg-slate-100 border-slate-200 text-blue-600'}`}><span className="font-extrabold text-sm sm:text-base md:text-xl">RM</span></div>}
            <div className="flex flex-col justify-center">
              <h2 className={`text-sm sm:text-base md:text-xl font-extrabold leading-none whitespace-nowrap ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Raihan Metadata</h2>
              <div><span className={`text-[8px] md:text-[10px] font-bold px-1.5 py-0.5 rounded inline-block tracking-widest uppercase mt-1 border ${theme === 'dark' ? 'text-[#00d4ff] bg-[#00d4ff]/10 border-[#00d4ff]/20' : 'text-blue-600 bg-blue-50 border-blue-200'}`}>Pro</span></div>
            </div>
          </div>
          <div className={`hidden md:flex space-x-8 font-bold items-center ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            <a href="#features" className={`transition-colors duration-300 ${theme === 'dark' ? 'hover:text-white' : 'hover:text-slate-900'}`}>Features</a>
            <button onClick={() => setCurrentView('demo')} className={`transition-colors duration-300 flex items-center gap-1 ${theme === 'dark' ? 'hover:text-white' : 'hover:text-slate-900'}`}><span>▶️</span> Demo Studio</button>
            <a href={siteData?.supportKoriLink || '#'} target="_blank" rel="noopener noreferrer" className={`transition-colors duration-300 ${theme === 'dark' ? 'hover:text-white' : 'hover:text-slate-900'}`}>Pricing</a>
            <button onClick={toggleTheme} className={`p-2 rounded-full shadow-sm border transition-colors ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'}`}>
              {theme === 'light' ? <span>🌙</span> : <span>☀️</span>}
            </button>
          </div>
          <div className="hidden md:flex items-center gap-4">
            <a href={siteData?.supportKoriLink || '#'} target="_blank" rel="noopener noreferrer" className={`btn-smooth px-6 py-2.5 rounded-full font-extrabold text-sm ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[0_0_20px_rgba(0,212,255,0.3)] hover:bg-[#00b8ff]' : 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:bg-blue-700'}`}>Get Access</a>
          </div>
          <div className="md:hidden flex items-center gap-3">
            <button onClick={toggleTheme} className={`p-2 rounded-full ${theme === 'dark' ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-700'}`}>
              {theme === 'light' ? <span>🌙</span> : <span>☀️</span>}
            </button>
            <button className={`p-2 btn-smooth ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`} onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              {isMobileMenuOpen ? <span>❌</span> : <span>☰</span>}
            </button>
          </div>
        </div>
        {isMobileMenuOpen && (
          <div className={`md:hidden absolute top-16 left-0 w-full backdrop-blur-3xl border-b p-4 flex flex-col gap-3 shadow-2xl transition-all duration-300 ease-[cubic-bezier(0.25,0.1,0.25,1)] ${isMobileMenuOpen ? 'opacity-100 translate-y-0 visible' : 'opacity-0 -translate-y-4 invisible'} ${theme === 'dark' ? 'bg-[#0f172a]/95 border-slate-800' : 'bg-white/95 border-slate-200'}`}>
            <a href="#features" onClick={() => setIsMobileMenuOpen(false)} className={`p-3.5 rounded-xl font-bold ${theme === 'dark' ? 'text-slate-300 bg-slate-800/50' : 'text-slate-700 bg-slate-50'}`}>Features</a>
            <button onClick={() => {setIsMobileMenuOpen(false); setCurrentView('demo');}} className={`p-3.5 rounded-xl font-bold text-left flex items-center gap-2 ${theme === 'dark' ? 'text-slate-300 bg-slate-800/50' : 'text-slate-700 bg-slate-50'}`}><span>▶️</span> Watch Demo</button>
            <a href={siteData?.supportKoriLink || '#'} target="_blank" rel="noopener noreferrer" onClick={() => setIsMobileMenuOpen(false)} className={`w-full text-center py-4 mt-2 rounded-2xl font-extrabold btn-smooth ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[0_0_20px_rgba(0,212,255,0.3)]' : 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]'}`}>Get Access Now</a>
          </div>
        )}
      </nav>

      <header className="relative z-10 pt-6 pb-12 sm:pt-8 sm:pb-16 md:pt-24 md:pb-28 px-3 sm:px-4 max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-6 md:gap-12 overflow-hidden animate-fade-in-up">
        <div className="w-[90%] sm:w-1/2 relative h-[150px] sm:h-[180px] md:h-[280px] flex justify-center items-center perspective-1000 mt-2 md:mt-0 mx-auto">
          {safeBanners.map((banner, index) => {
            const total = safeBanners.length || 1;
            const diff = (index - activeBannerIndex + total) % total;
            let zIndex = 30 - diff * 10;
            let transform = `translateY(${diff * 6}px) translateX(${diff * 6}px) rotate(${paperRotations[index] || 0}deg) scale(${1 - diff * 0.05})`;
            let opacity = diff === 0 ? 1 : diff === 1 ? 0.6 : diff === 2 ? 0.2 : 0;
            return (
              <div key={banner?.id || index} className={`absolute w-full max-w-[450px] aspect-video rounded-lg sm:rounded-xl md:rounded-2xl border overflow-hidden p-1 md:p-1.5 transition-all duration-700 ease-out ${theme === 'dark' ? 'border-slate-700 shadow-[0_20px_50px_rgba(0,0,0,0.5)] bg-slate-900' : 'border-slate-200 shadow-[0_20px_50px_rgba(0,0,0,0.1)] bg-white'}`} style={{ zIndex, transform, opacity }}>
                <img src={banner?.image || ''} alt="banner" className="w-full h-full object-cover rounded-md sm:rounded-lg md:rounded-xl" decoding="async" loading="lazy" />
              </div>
            );
          })}
        </div>
        <div className="w-full sm:w-1/2 text-center md:text-left z-20">
          <div key={activeBannerIndex} className="animate-fade-in-up">
            <h1 className={`text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black mb-3 md:mb-5 leading-tight font-bangla tracking-tight ${theme === 'dark' ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-[#00d4ff] drop-shadow-lg' : 'text-slate-900 drop-shadow-sm'}`}>{safeBanners[activeBannerIndex]?.title || "Raihan Metadata"}</h1>
            <p className={`text-xs sm:text-sm md:text-lg mb-5 md:mb-8 font-bangla leading-snug md:leading-relaxed md:border-l-[4px] md:pl-4 max-w-lg mx-auto md:mx-0 font-medium ${theme === 'dark' ? 'text-slate-400 border-[#00d4ff]' : 'text-slate-600 border-blue-600'}`}>{safeBanners[activeBannerIndex]?.desc || "Welcome to the ultimate extension."}</p>
          </div>
          <div className="flex flex-row justify-center md:justify-start gap-3 md:gap-4">
            <a href={siteData?.supportKoriLink || '#'} target="_blank" rel="noopener noreferrer" className={`btn-smooth flex items-center justify-center gap-1.5 md:gap-2 px-5 py-3 md:px-8 md:py-4 rounded-xl md:rounded-full text-xs md:text-lg font-extrabold ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[0_0_20px_rgba(0,212,255,0.4)] hover:bg-[#00b8ff]' : 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:bg-blue-700'}`}>
               Get Extension <span>➡️</span>
            </a>
            <button onClick={() => setCurrentView('demo')} className={`btn-smooth flex items-center justify-center gap-1.5 md:gap-2 border px-5 py-3 md:px-8 md:py-4 rounded-xl md:rounded-full text-xs md:text-lg font-extrabold shadow-sm ${theme === 'dark' ? 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700' : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'}`}>
              <span className={theme === 'dark' ? 'text-[#00d4ff]' : 'text-blue-600'}>▶️</span> Watch Demo
            </button>
          </div>
        </div>
      </header>

      <section id="features" className={`relative z-10 py-12 sm:py-16 md:py-24 border-y transition-colors duration-500 ${theme === 'dark' ? 'bg-[#0a0f1c] border-slate-800/50' : 'bg-white border-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10 md:mb-16">
             <h2 className={`text-2xl md:text-4xl font-black ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Why Professionals Choose Us</h2>
             <p className={`mt-3 text-sm md:text-base ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Designed to save hours of manual metadata entry.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 animate-fade-in-up">
            {[{ title: "অটোমেটিক মেটাডাটা", icon: <span className={`text-[24px] ${theme === 'dark' ? 'text-[#00d4ff]' : 'text-blue-600'}`}>⚡</span>, desc: "ইমেজ আপলোড করার সাথে সাথেই টাইটেল ও ট্যাগ জেনারেট হবে।" }, { title: "ডুয়্যাল সাপোর্ট", icon: <span className={`text-[24px] ${theme === 'dark' ? 'text-[#00d4ff]' : 'text-blue-600'}`}>📑</span>, desc: "Adobe Stock এবং Shutterstock-এ সমানভাবে কাজ করে।" }, { title: "ডিভাইস লক সুরক্ষা", icon: <span className={`text-[24px] ${theme === 'dark' ? 'text-[#00d4ff]' : 'text-blue-600'}`}>🛡️</span>, desc: "একটি লাইসেন্স শুধুমাত্র একটি পিসিতেই ব্যবহারযোগ্য।" }].map((f, i) => (
              <div key={i} className={`hover-card p-6 md:p-8 rounded-3xl border text-center flex flex-col items-center backdrop-blur-sm group ${theme === 'dark' ? 'bg-slate-900/50 border-slate-800 shadow-lg hover:border-[#00d4ff]/50' : 'bg-slate-50 border-slate-200 shadow-md hover:border-blue-300'}`}>
                <div className={`mb-6 w-16 h-16 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300 border ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-white border-[#00d4ff]/20' : 'bg-blue-100 text-slate-900 border-blue-200'}`}>{f.icon}</div>
                <h4 className={`text-lg md:text-xl font-extrabold mb-3 font-bangla ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{f.title}</h4>
                <p className={`text-sm md:text-base font-bangla leading-relaxed ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="products" className={`relative z-10 py-12 sm:py-16 md:py-24 animate-fade-in-up transition-colors duration-500 ${theme === 'dark' ? 'bg-[#020617]' : 'bg-slate-50'}`}>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className={`text-2xl sm:text-3xl md:text-5xl font-black mb-8 sm:mb-10 md:mb-16 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Simple, Transparent Pricing</h2>
          <div className="flex flex-col gap-6 sm:gap-8 md:gap-10 max-w-5xl mx-auto">
            {safeProducts.map((product, index) => {
              if (!product) return null;
              return (
              <div key={product.id || index} className={`p-4 sm:p-6 md:p-10 flex flex-col md:flex-row items-center gap-6 md:gap-10 rounded-3xl md:rounded-[2.5rem] border hover-card group backdrop-blur-md relative overflow-hidden ${theme === 'dark' ? 'bg-slate-900/80 border-slate-800 shadow-2xl' : 'bg-white border-slate-200 shadow-xl'}`}>
                <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent to-transparent opacity-50 ${theme === 'dark' ? 'via-[#00d4ff]' : 'via-blue-600'}`}></div>
                <img src={product.image || ''} alt={product.title || 'Product'} className={`w-full md:w-1/2 h-56 md:h-80 object-cover rounded-2xl shadow-lg transition-transform duration-700 group-hover:scale-105 border ${theme === 'dark' ? 'border-slate-700/50' : 'border-slate-200'}`} decoding="async" loading="lazy" />
                <div className="text-center md:text-left w-full md:w-1/2">
                  <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold mb-4 border ${theme === 'dark' ? 'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/20' : 'bg-blue-50 text-blue-600 border-blue-200'}`}>MOST POPULAR</div>
                  <h3 className={`text-2xl md:text-4xl font-extrabold mb-3 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{product.title || ''}</h3>
                  <div className={`text-3xl md:text-5xl font-black mb-4 font-bangla tracking-tight ${theme === 'dark' ? 'text-[#00d4ff] drop-shadow-md' : 'text-blue-600 drop-shadow-sm'}`}>{product.price || ''}</div>
                  <p className={`text-sm md:text-base mb-8 font-bangla leading-relaxed ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>{product.desc || ''}</p>
                  <a href={siteData?.supportKoriLink || '#'} target="_blank" rel="noopener noreferrer" className={`btn-smooth block w-full md:inline-block md:w-auto px-8 py-4 rounded-full font-extrabold text-base ${theme === 'dark' ? 'bg-white text-[#0B1221] shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:bg-slate-200' : 'bg-blue-600 text-white shadow-[0_5px_15px_rgba(37,99,235,0.3)] hover:bg-blue-700'}`}>
                    Get Lifetime License Now
                  </a>
                </div>
              </div>
            )})}
          </div>
        </div>
      </section>

      <footer className={`relative z-10 py-16 text-center px-4 overflow-hidden border-t mt-12 transition-colors duration-500 ${theme === 'dark' ? 'bg-[#0a0f1c] border-slate-800/50' : 'bg-white border-slate-200'}`}>
        <div className="max-w-7xl mx-auto flex flex-col items-center relative z-10">
          <h2 className={`text-2xl md:text-4xl font-black mb-3 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Want to automate your workflow?</h2>
          <p className={`text-sm md:text-base mb-10 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Save hours of manual tagging and start uploading instantly.</p>
          <a href={siteData?.supportKoriLink || '#'} target="_blank" rel="noopener noreferrer" className={`btn-smooth px-8 py-4 rounded-full font-black mb-16 text-base ${theme === 'dark' ? 'bg-[#00d4ff] text-[#0B1221] shadow-[0_0_30px_rgba(0,212,255,0.3)] hover:bg-[#00b8ff]' : 'bg-blue-600 text-white shadow-[0_5px_15px_rgba(37,99,235,0.3)] hover:bg-blue-700'}`}>
            GET EXTENSION NOW
          </a>
          <div className={`w-full border-t pt-8 flex flex-col items-center ${theme === 'dark' ? 'border-slate-800/50' : 'border-slate-200'}`}>
            <div className={`flex items-center gap-2 mb-4 grayscale ${theme === 'dark' ? 'opacity-50' : 'opacity-70'}`}>
              <span className={theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}>🛡️</span>
              <span className={`font-bold text-sm ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>Secured by SupportKori</span>
            </div>
            <p className="text-slate-500 text-xs md:text-sm font-medium">© 2026 Raihan Metadata Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

// ==========================================
// 🚀 FINAL EXPORT WITH ERROR BOUNDARY 🚀
// ==========================================
export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}
