import { createClient } from '@supabase/supabase-js';

// Vercel-এর পুরনো সেটিং বাইপাস করে সরাসরি ফিক্সড URL ও Key 
const supabaseUrl = 'https://gfjqjislhsnttsscytza.supabase.co';

const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdmanFqaXNsaHNudHRzc2N5dHphIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAwMjc1MTcsImV4cCI6MjA4NTYwMzUxN30.q2_C7r2K-jY8MDezBq5DKKZQ6kly90ZqjAe8lSrqnqU';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
